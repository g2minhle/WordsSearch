// Borland C++ Builder
// Copyright (c) 1995, 1999 by Borland International
// All rights reserved

// (DO NOT EDIT: machine generated header) 'SUI2SkinReader.pas' rev: 5.00

#ifndef SUI2SkinReaderHPP
#define SUI2SkinReaderHPP

#pragma delphiheader begin
#pragma option push -w-
#pragma option push -Vx
#include <Graphics.hpp>	// Pascal unit
#include <SysUtils.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <Windows.hpp>	// Pascal unit
#include <SysInit.hpp>	// Pascal unit
#include <System.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Sui2skinreader
{
//-- type declarations -------------------------------------------------------
class DELPHICLASS Tsk2SkinFileReader;
class PASCALIMPLEMENTATION Tsk2SkinFileReader : public System::TObject 
{
	typedef System::TObject inherited;
	
private:
	Classes::TStrings* m_BitmapList;
	Classes::TStrings* m_IntegerList;
	Classes::TStrings* m_BooleanList;
	Classes::TStrings* m_StrList;
	bool m_Ready;
	void __fastcall Load(AnsiString FileName, AnsiString Password);
	
public:
	__fastcall Tsk2SkinFileReader(AnsiString FileName, AnsiString Password);
	__fastcall virtual ~Tsk2SkinFileReader(void);
	Graphics::TBitmap* __fastcall GetBitmap(AnsiString Key);
	int __fastcall GetInteger(AnsiString Key);
	bool __fastcall GetBool(AnsiString Key);
	AnsiString __fastcall GetStr(AnsiString Key);
	void __fastcall SetInteger(AnsiString Key, int Value);
	void __fastcall SetBool(AnsiString Key, bool Value);
	void __fastcall SetBitmap(AnsiString Key, const Graphics::TBitmap* Buf);
	void __fastcall ProcessTransparentColor(Graphics::TColor TransColor);
	__property bool Ready = {read=m_Ready, nodefault};
};


//-- var, const, procedure ---------------------------------------------------

}	/* namespace Sui2skinreader */
#if !defined(NO_IMPLICIT_NAMESPACE_USE)
using namespace Sui2skinreader;
#endif
#pragma option pop	// -w-
#pragma option pop	// -Vx

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// SUI2SkinReader
