// CodeGear C++Builder
// Copyright (c) 1995, 2008 by CodeGear
// All rights reserved

// (DO NOT EDIT: machine generated header) 'Suimgr.pas' rev: 20.00

#ifndef SuimgrHPP
#define SuimgrHPP

#pragma delphiheader begin
#pragma option push
#pragma option -w-      // All warnings off
#pragma option -Vx      // Zero-length empty class member functions
#pragma pack(push,8)
#include <System.hpp>	// Pascal unit
#include <Sysinit.hpp>	// Pascal unit
#include <Windows.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <Controls.hpp>	// Pascal unit
#include <Sysutils.hpp>	// Pascal unit
#include <Forms.hpp>	// Pascal unit
#include <Typinfo.hpp>	// Pascal unit
#include <Graphics.hpp>	// Pascal unit
#include <Dialogs.hpp>	// Pascal unit
#include <Suithemes.hpp>	// Pascal unit
#include <Sui2define.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Suimgr
{
//-- type declarations -------------------------------------------------------
class DELPHICLASS TsuiFileTheme;
class PASCALIMPLEMENTATION TsuiFileTheme : public Classes::TComponent
{
	typedef Classes::TComponent inherited;
	
private:
	Suithemes::TsuiFileThemeMgr* m_Mgr;
	System::UnicodeString m_ThemeFile;
	bool m_CanUse;
	System::UnicodeString m_Password;
	void __fastcall SetThemeFile(const System::UnicodeString Value);
	void __fastcall SetCanUse(const bool Value);
	void __fastcall SetPassword(const System::UnicodeString Value);
	
public:
	__fastcall virtual TsuiFileTheme(Classes::TComponent* AOwner);
	__fastcall virtual ~TsuiFileTheme(void);
	bool __fastcall CanUse(void);
	Graphics::TBitmap* __fastcall GetBitmap(const Sui2define::Tsk2SkinBitmapElement Index);
	void __fastcall GetBitmap2(const Sui2define::Tsk2SkinBitmapElement Index, const Graphics::TBitmap* Buf, int SpitCount, int SpitIndex);
	int __fastcall GetInt(const Sui2define::Tsk2IntElement Index);
	Graphics::TColor __fastcall GetColor(const Sui2define::Tsk2SkinColorElement Index);
	bool __fastcall GetBool(const Sui2define::Tsk2BoolElement Index);
	
__published:
	__property System::UnicodeString ThemeFile = {read=m_ThemeFile, write=SetThemeFile};
	__property System::UnicodeString Password = {read=m_Password, write=SetPassword};
	__property bool Ready = {read=m_CanUse, write=SetCanUse, nodefault};
};


class DELPHICLASS TsuiBuiltInFileTheme;
class PASCALIMPLEMENTATION TsuiBuiltInFileTheme : public TsuiFileTheme
{
	typedef TsuiFileTheme inherited;
	
private:
	System::UnicodeString m_OldThemeFile;
	void __fastcall SetThemeFile2(const System::UnicodeString Value);
	void __fastcall ReadSkinData(Classes::TStream* Stream);
	void __fastcall WriteSkinData(Classes::TStream* Stream);
	
protected:
	virtual void __fastcall DefineProperties(Classes::TFiler* Filer);
	
__published:
	__property System::UnicodeString ThemeFile = {read=m_OldThemeFile, write=SetThemeFile2};
public:
	/* TsuiFileTheme.Create */ inline __fastcall virtual TsuiBuiltInFileTheme(Classes::TComponent* AOwner) : TsuiFileTheme(AOwner) { }
	/* TsuiFileTheme.Destroy */ inline __fastcall virtual ~TsuiBuiltInFileTheme(void) { }
	
};


class DELPHICLASS TsuiThemeMgrCompList;
class PASCALIMPLEMENTATION TsuiThemeMgrCompList : public Classes::TStringList
{
	typedef Classes::TStringList inherited;
	
public:
	/* TStringList.Create */ inline __fastcall TsuiThemeMgrCompList(void)/* overload */ : Classes::TStringList() { }
	/* TStringList.Destroy */ inline __fastcall virtual ~TsuiThemeMgrCompList(void) { }
	
};


class DELPHICLASS TsuiThemeManager;
class PASCALIMPLEMENTATION TsuiThemeManager : public Classes::TComponent
{
	typedef Classes::TComponent inherited;
	
private:
	Suithemes::TsuiUIStyle m_UIStyle;
	TsuiFileTheme* m_FileTheme;
	TsuiThemeMgrCompList* m_List;
	Classes::TNotifyEvent m_OnUIStyleChanged;
	void __fastcall SetUIStyle(const Suithemes::TsuiUIStyle Value);
	void __fastcall UpdateAll(void);
	void __fastcall SetList(const TsuiThemeMgrCompList* Value);
	void __fastcall SetFileTheme(const TsuiFileTheme* Value);
	
protected:
	virtual void __fastcall Notification(Classes::TComponent* AComponent, Classes::TOperation Operation);
	
public:
	__fastcall virtual TsuiThemeManager(Classes::TComponent* AOwner);
	__fastcall virtual ~TsuiThemeManager(void);
	void __fastcall UpdateTheme(void);
	
__published:
	__property Suithemes::TsuiUIStyle UIStyle = {read=m_UIStyle, write=SetUIStyle, nodefault};
	__property TsuiFileTheme* FileTheme = {read=m_FileTheme, write=SetFileTheme};
	__property TsuiThemeMgrCompList* CompList = {read=m_List, write=SetList};
	__property Classes::TNotifyEvent OnUIStyleChanged = {read=m_OnUIStyleChanged, write=m_OnUIStyleChanged};
};


//-- var, const, procedure ---------------------------------------------------
extern PACKAGE void __fastcall ThemeManagerEdit(TsuiThemeManager* AComp);
extern PACKAGE void __fastcall FileThemeEdit(TsuiFileTheme* AComp);
extern PACKAGE void __fastcall BuiltInFileThemeEdit(TsuiBuiltInFileTheme* AComp);
extern PACKAGE bool __fastcall UsingFileTheme(const TsuiFileTheme* FileTheme, const Suithemes::TsuiUIStyle UIStyle, /* out */ Suithemes::TsuiUIStyle &SuggUIStyle);

}	/* namespace Suimgr */
using namespace Suimgr;
#pragma pack(pop)
#pragma option pop

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// SuimgrHPP
