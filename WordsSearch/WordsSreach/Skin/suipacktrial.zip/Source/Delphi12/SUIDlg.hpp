// CodeGear C++Builder
// Copyright (c) 1995, 2008 by CodeGear
// All rights reserved

// (DO NOT EDIT: machine generated header) 'Suidlg.pas' rev: 20.00

#ifndef SuidlgHPP
#define SuidlgHPP

#pragma delphiheader begin
#pragma option push
#pragma option -w-      // All warnings off
#pragma option -Vx      // Zero-length empty class member functions
#pragma pack(push,8)
#include <System.hpp>	// Pascal unit
#include <Sysinit.hpp>	// Pascal unit
#include <Controls.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <Math.hpp>	// Pascal unit
#include <Forms.hpp>	// Pascal unit
#include <Dialogs.hpp>	// Pascal unit
#include <Graphics.hpp>	// Pascal unit
#include <Sysutils.hpp>	// Pascal unit
#include <Suithemes.hpp>	// Pascal unit
#include <Suimgr.hpp>	// Pascal unit
#include <Sui2define.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Suidlg
{
//-- type declarations -------------------------------------------------------
typedef ShortInt TsuiDialogButtonsCount;

#pragma option push -b-
enum TsuiIconType { suiNone, suiWarning, suiStop, suiInformation, suiHelp };
#pragma option pop

class DELPHICLASS TsuiDialog;
class PASCALIMPLEMENTATION TsuiDialog : public Classes::TComponent
{
	typedef Classes::TComponent inherited;
	
private:
	Forms::TPosition m_Position;
	Controls::TCaption m_Caption;
	Controls::TCursor m_ButtonCursor;
	Suithemes::TsuiUIStyle m_UIStyle;
	Suimgr::TsuiFileTheme* m_FileTheme;
	Graphics::TFont* m_Font;
	Graphics::TFont* m_CaptionFont;
	void __fastcall SetFileTheme(const Suimgr::TsuiFileTheme* Value);
	void __fastcall SetUIStyle(const Suithemes::TsuiUIStyle Value);
	void __fastcall SetFont(const Graphics::TFont* Value);
	void __fastcall SetCaptionFont(const Graphics::TFont* Value);
	
protected:
	virtual void __fastcall Notification(Classes::TComponent* AComponent, Classes::TOperation Operation);
	__property Controls::TCursor ButtonCursor = {read=m_ButtonCursor, write=m_ButtonCursor, nodefault};
	
public:
	__fastcall virtual TsuiDialog(Classes::TComponent* AOwner);
	__fastcall virtual ~TsuiDialog(void);
	virtual Controls::TModalResult __fastcall ShowModal(void) = 0 ;
	
__published:
	__property Suimgr::TsuiFileTheme* FileTheme = {read=m_FileTheme, write=SetFileTheme};
	__property Forms::TPosition Position = {read=m_Position, write=m_Position, nodefault};
	__property Controls::TCaption Caption = {read=m_Caption, write=m_Caption};
	__property Suithemes::TsuiUIStyle UIStyle = {read=m_UIStyle, write=SetUIStyle, nodefault};
	__property Graphics::TFont* Font = {read=m_Font, write=SetFont};
	__property Graphics::TFont* CaptionFont = {read=m_CaptionFont, write=SetCaptionFont};
};


class DELPHICLASS TsuiMessageDialog;
class PASCALIMPLEMENTATION TsuiMessageDialog : public TsuiDialog
{
	typedef TsuiDialog inherited;
	
private:
	TsuiDialogButtonsCount m_ButtonCount;
	Controls::TCaption m_Button1Caption;
	Controls::TCaption m_Button2Caption;
	Controls::TCaption m_Button3Caption;
	Controls::TModalResult m_Button1ModalResult;
	Controls::TModalResult m_Button2ModalResult;
	Controls::TModalResult m_Button3ModalResult;
	TsuiIconType m_IconType;
	System::UnicodeString m_Text;
	
public:
	__fastcall virtual TsuiMessageDialog(Classes::TComponent* AOwner);
	virtual Controls::TModalResult __fastcall ShowModal(void);
	
__published:
	__property ButtonCursor;
	__property TsuiDialogButtonsCount ButtonCount = {read=m_ButtonCount, write=m_ButtonCount, nodefault};
	__property Controls::TCaption Button1Caption = {read=m_Button1Caption, write=m_Button1Caption};
	__property Controls::TCaption Button2Caption = {read=m_Button2Caption, write=m_Button2Caption};
	__property Controls::TCaption Button3Caption = {read=m_Button3Caption, write=m_Button3Caption};
	__property Controls::TModalResult Button1ModalResult = {read=m_Button1ModalResult, write=m_Button1ModalResult, nodefault};
	__property Controls::TModalResult Button2ModalResult = {read=m_Button2ModalResult, write=m_Button2ModalResult, nodefault};
	__property Controls::TModalResult Button3ModalResult = {read=m_Button3ModalResult, write=m_Button3ModalResult, nodefault};
	__property TsuiIconType IconType = {read=m_IconType, write=m_IconType, nodefault};
	__property System::UnicodeString Text = {read=m_Text, write=m_Text};
public:
	/* TsuiDialog.Destroy */ inline __fastcall virtual ~TsuiMessageDialog(void) { }
	
};


class DELPHICLASS TsuiPasswordDialog;
class PASCALIMPLEMENTATION TsuiPasswordDialog : public TsuiDialog
{
	typedef TsuiDialog inherited;
	
private:
	Controls::TCaption m_ButtonCancelCaption;
	Controls::TCaption m_ButtonOKCaption;
	Controls::TCaption m_Item1Caption;
	System::WideChar m_Item1PasswordChar;
	Controls::TCaption m_Item2Caption;
	System::WideChar m_Item2PasswordChar;
	System::UnicodeString m_Item1Text;
	System::UnicodeString m_Item2Text;
	
public:
	__fastcall virtual TsuiPasswordDialog(Classes::TComponent* AOwner);
	virtual Controls::TModalResult __fastcall ShowModal(void);
	
__published:
	__property Controls::TCaption Item1Caption = {read=m_Item1Caption, write=m_Item1Caption};
	__property Controls::TCaption Item2Caption = {read=m_Item2Caption, write=m_Item2Caption};
	__property System::WideChar Item1PasswordChar = {read=m_Item1PasswordChar, write=m_Item1PasswordChar, nodefault};
	__property System::WideChar Item2PasswordChar = {read=m_Item2PasswordChar, write=m_Item2PasswordChar, nodefault};
	__property System::UnicodeString Item1Text = {read=m_Item1Text, write=m_Item1Text};
	__property System::UnicodeString Item2Text = {read=m_Item2Text, write=m_Item2Text};
	__property Controls::TCaption ButtonOKCaption = {read=m_ButtonOKCaption, write=m_ButtonOKCaption};
	__property Controls::TCaption ButtonCancelCaption = {read=m_ButtonCancelCaption, write=m_ButtonCancelCaption};
	__property ButtonCursor;
public:
	/* TsuiDialog.Destroy */ inline __fastcall virtual ~TsuiPasswordDialog(void) { }
	
};


class DELPHICLASS TsuiInputDialog;
class PASCALIMPLEMENTATION TsuiInputDialog : public TsuiDialog
{
	typedef TsuiDialog inherited;
	
private:
	Controls::TCaption m_ButtonCancelCaption;
	Controls::TCaption m_ButtonOKCaption;
	System::UnicodeString m_PromptText;
	System::UnicodeString m_ValueText;
	System::WideChar m_PasswordChar;
	
public:
	__fastcall virtual TsuiInputDialog(Classes::TComponent* AOwner);
	virtual Controls::TModalResult __fastcall ShowModal(void);
	
__published:
	__property System::WideChar PasswordChar = {read=m_PasswordChar, write=m_PasswordChar, nodefault};
	__property System::UnicodeString PromptText = {read=m_PromptText, write=m_PromptText};
	__property System::UnicodeString ValueText = {read=m_ValueText, write=m_ValueText};
	__property Controls::TCaption ButtonOKCaption = {read=m_ButtonOKCaption, write=m_ButtonOKCaption};
	__property Controls::TCaption ButtonCancelCaption = {read=m_ButtonCancelCaption, write=m_ButtonCancelCaption};
	__property ButtonCursor;
public:
	/* TsuiDialog.Destroy */ inline __fastcall virtual ~TsuiInputDialog(void) { }
	
};


//-- var, const, procedure ---------------------------------------------------
extern PACKAGE Controls::TModalResult __fastcall SUIMsgDlg(const System::UnicodeString Msg, Dialogs::TMsgDlgType DlgType, Dialogs::TMsgDlgButtons Buttons, Suithemes::TsuiUIStyle UIStyle = (Suithemes::TsuiUIStyle)(0x3))/* overload */;
extern PACKAGE Controls::TModalResult __fastcall SUIMsgDlg(const System::UnicodeString Msg, const System::UnicodeString Caption, Dialogs::TMsgDlgType DlgType, Dialogs::TMsgDlgButtons Buttons, Suithemes::TsuiUIStyle UIStyle = (Suithemes::TsuiUIStyle)(0x3))/* overload */;
extern PACKAGE Controls::TModalResult __fastcall SUIMsgDlgFromSkinFile(const System::UnicodeString Msg, Dialogs::TMsgDlgType DlgType, Dialogs::TMsgDlgButtons Buttons, const Suimgr::TsuiFileTheme* FileTheme)/* overload */;
extern PACKAGE Controls::TModalResult __fastcall SUIMsgDlgFromSkinFile(const System::UnicodeString Msg, const System::UnicodeString Caption, Dialogs::TMsgDlgType DlgType, Dialogs::TMsgDlgButtons Buttons, const Suimgr::TsuiFileTheme* FileTheme)/* overload */;

}	/* namespace Suidlg */
using namespace Suidlg;
#pragma pack(pop)
#pragma option pop

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// SuidlgHPP
