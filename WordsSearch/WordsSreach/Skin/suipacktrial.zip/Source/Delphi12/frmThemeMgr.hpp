// CodeGear C++Builder
// Copyright (c) 1995, 2008 by CodeGear
// All rights reserved

// (DO NOT EDIT: machine generated header) 'Frmthememgr.pas' rev: 20.00

#ifndef FrmthememgrHPP
#define FrmthememgrHPP

#pragma delphiheader begin
#pragma option push
#pragma option -w-      // All warnings off
#pragma option -Vx      // Zero-length empty class member functions
#pragma pack(push,8)
#include <System.hpp>	// Pascal unit
#include <Sysinit.hpp>	// Pascal unit
#include <Windows.hpp>	// Pascal unit
#include <Messages.hpp>	// Pascal unit
#include <Sysutils.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <Graphics.hpp>	// Pascal unit
#include <Controls.hpp>	// Pascal unit
#include <Forms.hpp>	// Pascal unit
#include <Dialogs.hpp>	// Pascal unit
#include <Stdctrls.hpp>	// Pascal unit
#include <Checklst.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Frmthememgr
{
//-- type declarations -------------------------------------------------------
class DELPHICLASS TfrmMgr;
class PASCALIMPLEMENTATION TfrmMgr : public Forms::TForm
{
	typedef Forms::TForm inherited;
	
__published:
	Checklst::TCheckListBox* List;
	Stdctrls::TButton* btn_sel;
	Stdctrls::TButton* btn_unsel;
	Stdctrls::TButton* btn_ok;
	void __fastcall btn_selClick(System::TObject* Sender);
	void __fastcall btn_unselClick(System::TObject* Sender);
public:
	/* TCustomForm.Create */ inline __fastcall virtual TfrmMgr(Classes::TComponent* AOwner) : Forms::TForm(AOwner) { }
	/* TCustomForm.CreateNew */ inline __fastcall virtual TfrmMgr(Classes::TComponent* AOwner, int Dummy) : Forms::TForm(AOwner, Dummy) { }
	/* TCustomForm.Destroy */ inline __fastcall virtual ~TfrmMgr(void) { }
	
public:
	/* TWinControl.CreateParented */ inline __fastcall TfrmMgr(HWND ParentWindow) : Forms::TForm(ParentWindow) { }
	
};


//-- var, const, procedure ---------------------------------------------------

}	/* namespace Frmthememgr */
using namespace Frmthememgr;
#pragma pack(pop)
#pragma option pop

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// FrmthememgrHPP
