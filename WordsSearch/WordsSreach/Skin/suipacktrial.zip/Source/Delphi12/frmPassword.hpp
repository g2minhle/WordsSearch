// CodeGear C++Builder
// Copyright (c) 1995, 2008 by CodeGear
// All rights reserved

// (DO NOT EDIT: machine generated header) 'Frmpassword.pas' rev: 20.00

#ifndef FrmpasswordHPP
#define FrmpasswordHPP

#pragma delphiheader begin
#pragma option push
#pragma option -w-      // All warnings off
#pragma option -Vx      // Zero-length empty class member functions
#pragma pack(push,8)
#include <System.hpp>	// Pascal unit
#include <Sysinit.hpp>	// Pascal unit
#include <Windows.hpp>	// Pascal unit
#include <Messages.hpp>	// Pascal unit
#include <Sysutils.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <Graphics.hpp>	// Pascal unit
#include <Controls.hpp>	// Pascal unit
#include <Forms.hpp>	// Pascal unit
#include <Dialogs.hpp>	// Pascal unit
#include <Extctrls.hpp>	// Pascal unit
#include <Suiform.hpp>	// Pascal unit
#include <Stdctrls.hpp>	// Pascal unit
#include <Suiedit.hpp>	// Pascal unit
#include <Suibutton.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Frmpassword
{
//-- type declarations -------------------------------------------------------
class DELPHICLASS TfrmPass;
class PASCALIMPLEMENTATION TfrmPass : public Forms::TForm
{
	typedef Forms::TForm inherited;
	
__published:
	Suiform::TsuiForm* suiForm1;
	Suiedit::TsuiEdit* edt1;
	Stdctrls::TLabel* lbl1;
	Stdctrls::TLabel* lbl2;
	Suiedit::TsuiEdit* edt2;
	Suibutton::TsuiButton* btn1;
	Suibutton::TsuiButton* btn2;
	void __fastcall FormShow(System::TObject* Sender);
public:
	/* TCustomForm.Create */ inline __fastcall virtual TfrmPass(Classes::TComponent* AOwner) : Forms::TForm(AOwner) { }
	/* TCustomForm.CreateNew */ inline __fastcall virtual TfrmPass(Classes::TComponent* AOwner, int Dummy) : Forms::TForm(AOwner, Dummy) { }
	/* TCustomForm.Destroy */ inline __fastcall virtual ~TfrmPass(void) { }
	
public:
	/* TWinControl.CreateParented */ inline __fastcall TfrmPass(HWND ParentWindow) : Forms::TForm(ParentWindow) { }
	
};


//-- var, const, procedure ---------------------------------------------------
extern PACKAGE TfrmPass* frmPass;

}	/* namespace Frmpassword */
using namespace Frmpassword;
#pragma pack(pop)
#pragma option pop

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// FrmpasswordHPP
