// CodeGear C++Builder
// Copyright (c) 1995, 2008 by CodeGear
// All rights reserved

// (DO NOT EDIT: machine generated header) 'Suititlebar.pas' rev: 20.00

#ifndef SuititlebarHPP
#define SuititlebarHPP

#pragma delphiheader begin
#pragma option push
#pragma option -w-      // All warnings off
#pragma option -Vx      // Zero-length empty class member functions
#pragma pack(push,8)
#include <System.hpp>	// Pascal unit
#include <Sysinit.hpp>	// Pascal unit
#include <Windows.hpp>	// Pascal unit
#include <Controls.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <Forms.hpp>	// Pascal unit
#include <Messages.hpp>	// Pascal unit
#include <Graphics.hpp>	// Pascal unit
#include <Menus.hpp>	// Pascal unit
#include <Extctrls.hpp>	// Pascal unit
#include <Dialogs.hpp>	// Pascal unit
#include <Sysutils.hpp>	// Pascal unit
#include <Math.hpp>	// Pascal unit
#include <Sui2define.hpp>	// Pascal unit
#include <Suithemes.hpp>	// Pascal unit
#include <Suimgr.hpp>	// Pascal unit
#include <Suipopupmenu.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Suititlebar
{
//-- type declarations -------------------------------------------------------
typedef void __fastcall (__closure *TsuiTitleBarButtonClickEvent)(System::TObject* Sender, int ButtonIndex);

typedef void __fastcall (__closure *TsuiTitleBarButtonClickEvent2)(System::TObject* Sender, bool &Allow);

class DELPHICLASS TsuiTitleBarPopupMenu;
class DELPHICLASS TsuiTitleBar;
class PASCALIMPLEMENTATION TsuiTitleBarPopupMenu : public Suipopupmenu::TsuiPopupMenu
{
	typedef Suipopupmenu::TsuiPopupMenu inherited;
	
private:
	TsuiTitleBar* m_TitleBar;
	void __fastcall OnMin(System::TObject* Sender);
	void __fastcall OnMax(System::TObject* Sender);
	void __fastcall OnClose(System::TObject* Sender);
	
public:
	__fastcall virtual TsuiTitleBarPopupMenu(Classes::TComponent* AOwner);
	__fastcall virtual ~TsuiTitleBarPopupMenu(void);
	virtual void __fastcall Popup(int X, int Y);
	__property TsuiTitleBar* TitleBar = {read=m_TitleBar, write=m_TitleBar};
};


class DELPHICLASS TsuiTitleBarSections;
class DELPHICLASS TsuiTitleBarButtons;
class PASCALIMPLEMENTATION TsuiTitleBar : public Extctrls::TCustomPanel
{
	typedef Extctrls::TCustomPanel inherited;
	
private:
	Suithemes::TsuiUIStyle m_UIStyle;
	Suimgr::TsuiFileTheme* m_FileTheme;
	TsuiTitleBarSections* m_Sections;
	TsuiTitleBarButtons* m_Buttons;
	bool m_AutoSize;
	int m_ButtonInterval;
	Controls::TCaption m_Caption;
	bool m_Active;
	int m_LeftBtnXOffset;
	int m_RightBtnXOffset;
	int m_RoundCorner;
	int m_RoundCornerBottom;
	bool m_DrawAppIcon;
	bool m_SelfChanging;
	TsuiTitleBarPopupMenu* m_DefPopupMenu;
	Graphics::TColor m_BorderColor;
	bool m_Custom;
	bool m_FiveSec;
	System::UnicodeString m_DrawingCap;
	Graphics::TBitmap* m_Buf;
	Graphics::TBitmap* m_Buf2;
	Graphics::TColor m_FormColor;
	Graphics::TColor m_TransColor;
	Graphics::TColor m_InactiveCaptionColor;
	bool m_MouseDown;
	int m_InButtons;
	int m_BtnHeight;
	int m_BtnTop;
	int m_IconTop;
	int m_CapTop;
	TsuiTitleBarButtonClickEvent m_OnBtnClick;
	TsuiTitleBarButtonClickEvent m_OnHelpBtnClick;
	TsuiTitleBarButtonClickEvent2 m_OnMinClick;
	TsuiTitleBarButtonClickEvent2 m_OnMaxClick;
	void __fastcall SetButtons(const TsuiTitleBarButtons* Value);
	void __fastcall SetSections(const TsuiTitleBarSections* Value);
	void __fastcall SetUIStyle(const Suithemes::TsuiUIStyle Value);
	void __fastcall SetButtonInterval(const int Value);
	void __fastcall SetCaption(const Controls::TCaption Value);
	void __fastcall SetActive(const bool Value);
	void __fastcall SetAutoSize2(bool Value);
	void __fastcall SetLeftBtnXOffset(const int Value);
	void __fastcall SetRightBtnXOffset(const int Value);
	void __fastcall SetDrawAppIcon(const bool Value);
	void __fastcall SetRoundCorner(const int Value);
	void __fastcall SetRoundCornerBottom(const int Value);
	void __fastcall SetFileTheme(const Suimgr::TsuiFileTheme* Value);
	void __fastcall SetInactiveCaptionColor(const Graphics::TColor Value);
	void __fastcall UpdateInsideTheme(Suithemes::TsuiUIStyle UIStyle);
	void __fastcall UpdateFileTheme(void);
	HIDESBASE MESSAGE void __fastcall WMERASEBKGND(Messages::TMessage &Msg);
	HIDESBASE MESSAGE void __fastcall CMFONTCHANGED(Messages::TMessage &Msg);
	HIDESBASE MESSAGE void __fastcall WMNCLBUTTONDOWN(Messages::TMessage &Msg);
	MESSAGE void __fastcall WMNCLBUTTONUP(Messages::TMessage &Msg);
	MESSAGE void __fastcall WMNCMOUSEMOVE(Messages::TMessage &Msg);
	HIDESBASE MESSAGE void __fastcall CMDesignHitTest(Messages::TWMMouse &Msg);
	
protected:
	virtual void __fastcall Paint(void);
	DYNAMIC void __fastcall MouseDown(Controls::TMouseButton Button, Classes::TShiftState Shift, int X, int Y);
	DYNAMIC void __fastcall MouseMove(Classes::TShiftState Shift, int X, int Y);
	DYNAMIC void __fastcall MouseUp(Controls::TMouseButton Button, Classes::TShiftState Shift, int X, int Y);
	DYNAMIC void __fastcall DblClick(void);
	MESSAGE void __fastcall MouseOut(Messages::TMessage &Msg);
	virtual void __fastcall Notification(Classes::TComponent* AComponent, Classes::TOperation Operation);
	virtual void __fastcall DrawSectionsTo(Graphics::TBitmap* Buf);
	virtual void __fastcall DrawButtons(Graphics::TBitmap* Buf);
	bool __fastcall InForm(void);
	bool __fastcall InMDIForm(void);
	
public:
	__fastcall virtual TsuiTitleBar(Classes::TComponent* AOwner);
	__fastcall virtual ~TsuiTitleBar(void);
	void __fastcall ProcessMaxBtn(void);
	void __fastcall GetTitleImage(int index, /* out */ Graphics::TBitmap* &Bmp);
	bool __fastcall CanPaint(void);
	void __fastcall ForcePaint(void);
	void __fastcall AddHelpBtn(void);
	__property TsuiTitleBarPopupMenu* DefPopupMenu = {read=m_DefPopupMenu};
	
__published:
	__property bool Custom = {read=m_Custom, write=m_Custom, nodefault};
	__property Suimgr::TsuiFileTheme* FileTheme = {read=m_FileTheme, write=SetFileTheme};
	__property Suithemes::TsuiUIStyle UIStyle = {read=m_UIStyle, write=SetUIStyle, nodefault};
	__property AutoSize = {read=m_AutoSize, write=SetAutoSize2, default=0};
	__property BiDiMode;
	__property Height;
	__property TsuiTitleBarSections* Sections = {read=m_Sections, write=SetSections};
	__property TsuiTitleBarButtons* Buttons = {read=m_Buttons, write=SetButtons};
	__property int ButtonInterval = {read=m_ButtonInterval, write=SetButtonInterval, nodefault};
	__property Caption = {read=m_Caption, write=SetCaption};
	__property Font;
	__property bool FormActive = {read=m_Active, write=SetActive, nodefault};
	__property int LeftBtnXOffset = {read=m_LeftBtnXOffset, write=SetLeftBtnXOffset, nodefault};
	__property int RightBtnXOffset = {read=m_RightBtnXOffset, write=SetRightBtnXOffset, nodefault};
	__property bool DrawAppIcon = {read=m_DrawAppIcon, write=SetDrawAppIcon, nodefault};
	__property int RoundCorner = {read=m_RoundCorner, write=SetRoundCorner, nodefault};
	__property int RoundCornerBottom = {read=m_RoundCornerBottom, write=SetRoundCornerBottom, nodefault};
	__property Graphics::TColor InactiveCaptionColor = {read=m_InactiveCaptionColor, write=SetInactiveCaptionColor, nodefault};
	__property TsuiTitleBarButtonClickEvent OnCustomBtnsClick = {read=m_OnBtnClick, write=m_OnBtnClick};
	__property TsuiTitleBarButtonClickEvent OnHelpBtnClick = {read=m_OnHelpBtnClick, write=m_OnHelpBtnClick};
	__property TsuiTitleBarButtonClickEvent2 OnMinClick = {read=m_OnMinClick, write=m_OnMinClick};
	__property TsuiTitleBarButtonClickEvent2 OnMaxClick = {read=m_OnMaxClick, write=m_OnMaxClick};
	__property OnResize;
public:
	/* TWinControl.CreateParented */ inline __fastcall TsuiTitleBar(HWND ParentWindow) : Extctrls::TCustomPanel(ParentWindow) { }
	
};


#pragma option push -b-
enum TsuiTitleBarBtnType { suiMax, suiMin, suiClose, suiHelp, suiControlBox, suiCustom };
#pragma option pop

class DELPHICLASS TsuiTitleBarButton;
class PASCALIMPLEMENTATION TsuiTitleBarButton : public Classes::TCollectionItem
{
	typedef Classes::TCollectionItem inherited;
	
private:
	bool m_Visible;
	TsuiTitleBarBtnType m_ButtonType;
	bool m_Transparent;
	int m_Top;
	Suithemes::TsuiUIStyle m_UIStyle;
	Graphics::TPicture* m_PicNormal;
	Graphics::TPicture* m_PicMouseOn;
	Graphics::TPicture* m_PicMouseDown;
	Menus::TPopupMenu* m_ControlBoxMenu;
	void __fastcall SetButtonType(const TsuiTitleBarBtnType Value);
	void __fastcall SetTransparent(const bool Value);
	void __fastcall SetTop(const int Value);
	void __fastcall SetUIStyle(const Suithemes::TsuiUIStyle Value);
	void __fastcall SetPicNormal(const Graphics::TPicture* Value);
	void __fastcall SetPicMouseOn(const Graphics::TPicture* Value);
	void __fastcall SetPicMouseDown(const Graphics::TPicture* Value);
	void __fastcall UpdateUIStyle(void);
	void __fastcall UpdateInsideTheme(Suithemes::TsuiUIStyle UIStyle);
	void __fastcall UpdateFileTheme(void);
	void __fastcall ProcessMaxBtn(void);
	void __fastcall SetVisible(const bool Value);
	
public:
	void __fastcall DoClick(void);
	__fastcall virtual TsuiTitleBarButton(Classes::TCollection* Collection);
	__fastcall virtual ~TsuiTitleBarButton(void);
	virtual void __fastcall Assign(Classes::TPersistent* Source);
	
__published:
	__property Suithemes::TsuiUIStyle UIStyle = {read=m_UIStyle, write=SetUIStyle, nodefault};
	__property TsuiTitleBarBtnType ButtonType = {read=m_ButtonType, write=SetButtonType, nodefault};
	__property bool Transparent = {read=m_Transparent, write=SetTransparent, nodefault};
	__property int Top = {read=m_Top, write=SetTop, nodefault};
	__property Menus::TPopupMenu* ControlBoxMenu = {read=m_ControlBoxMenu, write=m_ControlBoxMenu};
	__property bool Visible = {read=m_Visible, write=SetVisible, nodefault};
	__property Graphics::TPicture* PicNormal = {read=m_PicNormal, write=SetPicNormal};
	__property Graphics::TPicture* PicMouseOn = {read=m_PicMouseOn, write=SetPicMouseOn};
	__property Graphics::TPicture* PicMouseDown = {read=m_PicMouseDown, write=SetPicMouseDown};
};


class PASCALIMPLEMENTATION TsuiTitleBarButtons : public Classes::TCollection
{
	typedef Classes::TCollection inherited;
	
private:
	TsuiTitleBar* m_TitleBar;
	
protected:
	HIDESBASE TsuiTitleBarButton* __fastcall GetItem(int Index);
	HIDESBASE void __fastcall SetItem(int Index, TsuiTitleBarButton* Value);
	virtual void __fastcall Update(Classes::TCollectionItem* Item);
	DYNAMIC Classes::TPersistent* __fastcall GetOwner(void);
	
public:
	HIDESBASE TsuiTitleBarButton* __fastcall Add(void);
	__fastcall TsuiTitleBarButtons(TsuiTitleBar* TitleBar);
	__property TsuiTitleBarButton* Items[int Index] = {read=GetItem, write=SetItem};
public:
	/* TCollection.Destroy */ inline __fastcall virtual ~TsuiTitleBarButtons(void) { }
	
};


#pragma option push -b-
enum TsuiTitleBarAlign { suiLeft, suiRight, suiClient };
#pragma option pop

class DELPHICLASS TsuiTitleBarSection;
class PASCALIMPLEMENTATION TsuiTitleBarSection : public Classes::TCollectionItem
{
	typedef Classes::TCollectionItem inherited;
	
private:
	int m_Width;
	TsuiTitleBarAlign m_Align;
	Graphics::TPicture* m_Picture;
	bool m_Stretch;
	bool m_AutoSize;
	bool m_CapSec;
	void __fastcall SetPicture(const Graphics::TPicture* Value);
	void __fastcall SetAutoSize(const bool Value);
	void __fastcall SetWidth(const int Value);
	void __fastcall SetAlign(const TsuiTitleBarAlign Value);
	void __fastcall SetStretch(const bool Value);
	void __fastcall SetCapSec(const bool Value);
	
public:
	__fastcall virtual TsuiTitleBarSection(Classes::TCollection* Collection);
	__fastcall virtual ~TsuiTitleBarSection(void);
	virtual void __fastcall Assign(Classes::TPersistent* Source);
	
__published:
	__property bool AutoSize = {read=m_AutoSize, write=SetAutoSize, nodefault};
	__property int Width = {read=m_Width, write=SetWidth, nodefault};
	__property TsuiTitleBarAlign Align = {read=m_Align, write=SetAlign, nodefault};
	__property Graphics::TPicture* Picture = {read=m_Picture, write=SetPicture};
	__property bool Stretch = {read=m_Stretch, write=SetStretch, nodefault};
	__property bool CapSec = {read=m_CapSec, write=SetCapSec, nodefault};
};


class PASCALIMPLEMENTATION TsuiTitleBarSections : public Classes::TCollection
{
	typedef Classes::TCollection inherited;
	
private:
	TsuiTitleBar* m_TitleBar;
	
protected:
	HIDESBASE TsuiTitleBarSection* __fastcall GetItem(int Index);
	HIDESBASE void __fastcall SetItem(int Index, TsuiTitleBarSection* Value);
	virtual void __fastcall Update(Classes::TCollectionItem* Item);
	DYNAMIC Classes::TPersistent* __fastcall GetOwner(void);
	
public:
	__fastcall TsuiTitleBarSections(TsuiTitleBar* TitleBar);
	__fastcall virtual ~TsuiTitleBarSections(void);
	HIDESBASE TsuiTitleBarSection* __fastcall Add(void);
	__property TsuiTitleBarSection* Items[int Index] = {read=GetItem, write=SetItem};
};


//-- var, const, procedure ---------------------------------------------------
static const Word SUIM_GETBORDERWIDTH = 0x26c3;

}	/* namespace Suititlebar */
using namespace Suititlebar;
#pragma pack(pop)
#pragma option pop

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// SuititlebarHPP
