// CodeGear C++Builder
// Copyright (c) 1995, 2008 by CodeGear
// All rights reserved

// (DO NOT EDIT: machine generated header) 'Suiresdef.pas' rev: 20.00

#ifndef SuiresdefHPP
#define SuiresdefHPP

#pragma delphiheader begin
#pragma option push
#pragma option -w-      // All warnings off
#pragma option -Vx      // Zero-length empty class member functions
#pragma pack(push,8)
#include <System.hpp>	// Pascal unit
#include <Sysinit.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Suiresdef
{
//-- type declarations -------------------------------------------------------
//-- var, const, procedure ---------------------------------------------------
extern PACKAGE System::ResourceString _SUI_TITLE_MENUITEM_MINIMIZE;
#define Suiresdef_SUI_TITLE_MENUITEM_MINIMIZE System::LoadResourceString(&Suiresdef::_SUI_TITLE_MENUITEM_MINIMIZE)
extern PACKAGE System::ResourceString _SUI_TITLE_MENUITEM_MAXIMIZE;
#define Suiresdef_SUI_TITLE_MENUITEM_MAXIMIZE System::LoadResourceString(&Suiresdef::_SUI_TITLE_MENUITEM_MAXIMIZE)
extern PACKAGE System::ResourceString _SUI_TITLE_MENUITEM_CLOSE;
#define Suiresdef_SUI_TITLE_MENUITEM_CLOSE System::LoadResourceString(&Suiresdef::_SUI_TITLE_MENUITEM_CLOSE)
extern PACKAGE System::ResourceString _SUI_URL;
#define Suiresdef_SUI_URL System::LoadResourceString(&Suiresdef::_SUI_URL)

}	/* namespace Suiresdef */
using namespace Suiresdef;
#pragma pack(pop)
#pragma option pop

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// SuiresdefHPP
