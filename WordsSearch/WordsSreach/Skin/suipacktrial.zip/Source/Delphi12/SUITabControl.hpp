// CodeGear C++Builder
// Copyright (c) 1995, 2008 by CodeGear
// All rights reserved

// (DO NOT EDIT: machine generated header) 'Suitabcontrol.pas' rev: 20.00

#ifndef SuitabcontrolHPP
#define SuitabcontrolHPP

#pragma delphiheader begin
#pragma option push
#pragma option -w-      // All warnings off
#pragma option -Vx      // Zero-length empty class member functions
#pragma pack(push,8)
#include <System.hpp>	// Pascal unit
#include <Sysinit.hpp>	// Pascal unit
#include <Windows.hpp>	// Pascal unit
#include <Messages.hpp>	// Pascal unit
#include <Sysutils.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <Controls.hpp>	// Pascal unit
#include <Extctrls.hpp>	// Pascal unit
#include <Forms.hpp>	// Pascal unit
#include <Graphics.hpp>	// Pascal unit
#include <Comctrls.hpp>	// Pascal unit
#include <Math.hpp>	// Pascal unit
#include <Imglist.hpp>	// Pascal unit
#include <Suithemes.hpp>	// Pascal unit
#include <Suimgr.hpp>	// Pascal unit
#include <Sui2define.hpp>	// Pascal unit
#include <Menus.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Suitabcontrol
{
//-- type declarations -------------------------------------------------------
#pragma option push -b-
enum TsuiTabPosition { suiTop, suiBottom };
#pragma option pop

typedef void __fastcall (__closure *TTabActiveNotify)(System::TObject* Sender, int TabIndex);

class DELPHICLASS TsuiTabControlTopPanel;
class DELPHICLASS TsuiTab;
class PASCALIMPLEMENTATION TsuiTabControlTopPanel : public Extctrls::TCustomPanel
{
	typedef Extctrls::TCustomPanel inherited;
	
private:
	Classes::TStrings* m_Tabs;
	Suithemes::TsuiUIStyle m_UIStyle;
	Suimgr::TsuiFileTheme* m_FileTheme;
	int m_TabIndex;
	int m_LeftMargin;
	StaticArray<int, 64> m_TabPos;
	int m_TabHeight;
	bool m_UserChanging;
	int m_Passed;
	bool m_ShowButton;
	int m_InButtons;
	Types::TPoint m_BtnSize;
	bool m_AutoFit;
	Graphics::TBitmap* m_ActiveTab;
	Graphics::TBitmap* m_InactiveTab;
	Graphics::TBitmap* m_Line;
	TsuiTabPosition m_TabPosition;
	Graphics::TColor m_ActiveTabFontColor;
	Graphics::TColor m_InactiveTabFontColor;
	void __fastcall OnTabsChange(System::TObject* Sender);
	void __fastcall SetTabs(const Classes::TStrings* Value);
	void __fastcall SetUIStyle(const Suithemes::TsuiUIStyle Value);
	void __fastcall SetLeftMargin(const int Value);
	void __fastcall SetTabIndex(const int Value);
	void __fastcall SetFileTheme(const Suimgr::TsuiFileTheme* Value);
	void __fastcall SetTabPosition(const TsuiTabPosition Value);
	HIDESBASE MESSAGE void __fastcall WMERASEBKGND(Messages::TMessage &Msg);
	int __fastcall PaintTabs(const Graphics::TBitmap* Buf);
	void __fastcall PaintButtons(const Graphics::TBitmap* Buf);
	int __fastcall GetInvisibleTabs(void);
	HIDESBASE MESSAGE void __fastcall WMKillFocus(Messages::TWMKillFocus &Msg);
	HIDESBASE MESSAGE void __fastcall WMSetFocus(Messages::TWMSetFocus &Msg);
	
protected:
	TsuiTab* m_TabControl;
	virtual void __fastcall Paint(void);
	DYNAMIC void __fastcall MouseDown(Controls::TMouseButton Button, Classes::TShiftState Shift, int X, int Y);
	DYNAMIC void __fastcall MouseMove(Classes::TShiftState Shift, int X, int Y);
	DYNAMIC void __fastcall KeyDown(System::Word &Key, Classes::TShiftState Shift);
	DYNAMIC void __fastcall DblClick(void);
	virtual void __fastcall RequestAlign(void);
	DYNAMIC void __fastcall Resize(void);
	
public:
	StaticArray<bool, 64> m_TabVisible;
	__fastcall TsuiTabControlTopPanel(Classes::TComponent* AOwner, TsuiTab* TabControl);
	__fastcall virtual ~TsuiTabControlTopPanel(void);
	
__published:
	__property Suimgr::TsuiFileTheme* FileTheme = {read=m_FileTheme, write=SetFileTheme};
	__property Suithemes::TsuiUIStyle UIStyle = {read=m_UIStyle, write=SetUIStyle, nodefault};
	__property Classes::TStrings* Tabs = {read=m_Tabs, write=SetTabs};
	__property int TabIndex = {read=m_TabIndex, write=SetTabIndex, nodefault};
	__property int LeftMargin = {read=m_LeftMargin, write=SetLeftMargin, nodefault};
	__property TsuiTabPosition TabPosition = {read=m_TabPosition, write=SetTabPosition, nodefault};
public:
	/* TWinControl.CreateParented */ inline __fastcall TsuiTabControlTopPanel(HWND ParentWindow) : Extctrls::TCustomPanel(ParentWindow) { }
	
};


class PASCALIMPLEMENTATION TsuiTab : public Extctrls::TCustomPanel
{
	typedef Extctrls::TCustomPanel inherited;
	
private:
	Suithemes::TsuiUIStyle m_UIStyle;
	Suimgr::TsuiFileTheme* m_FileTheme;
	Graphics::TColor m_BorderColor;
	Graphics::TFont* m_Font;
	TsuiTabPosition m_TabPosition;
	TTabActiveNotify m_OnTabActive;
	Classes::TNotifyEvent m_OnChange;
	Comctrls::TTabChangingEvent m_OnChanging;
	Imglist::TCustomImageList* m_ImageList;
	bool m_PageDrawFocused;
	void __fastcall SetFileTheme(const Suimgr::TsuiFileTheme* Value);
	void __fastcall SetUIStyle(const Suithemes::TsuiUIStyle Value);
	void __fastcall SetTabs(const Classes::TStrings* Value);
	Classes::TStrings* __fastcall GetTabs(void);
	int __fastcall GetLeftMargin(void);
	int __fastcall GetTabIndex(void);
	void __fastcall SetLeftMargin(const int Value);
	void __fastcall SetBorderColor(const Graphics::TColor Value);
	HIDESBASE void __fastcall SetFont(const Graphics::TFont* Value);
	void __fastcall SetTabPosition(const TsuiTabPosition Value);
	HIDESBASE MESSAGE void __fastcall CMCursorChanged(Messages::TMessage &Message);
	HIDESBASE MESSAGE void __fastcall WMERASEBKGND(Messages::TMessage &Message);
	void __fastcall TopPanelClick(System::TObject* Sender);
	void __fastcall TopPanelDblClick(System::TObject* Sender);
	void __fastcall SetImageList(const Imglist::TCustomImageList* Value);
	void __fastcall SetPageDrawFocused(const bool Value);
	
protected:
	TsuiTabControlTopPanel* m_TopPanel;
	virtual void __fastcall Notification(Classes::TComponent* AComponent, Classes::TOperation Operation);
	virtual void __fastcall Paint(void);
	virtual TsuiTabControlTopPanel* __fastcall CreateTopPanel(void) = 0 ;
	virtual int __fastcall GetImageIndex(int PageId) = 0 ;
	virtual void __fastcall SetTabIndex(const int Value);
	virtual void __fastcall BorderColorChanged(void);
	virtual void __fastcall AlignControls(Controls::TControl* AControl, Types::TRect &Rect);
	DYNAMIC void __fastcall Resize(void);
	__property Classes::TStrings* Tabs = {read=GetTabs, write=SetTabs};
	__property int TabIndex = {read=GetTabIndex, write=SetTabIndex, nodefault};
	virtual void __fastcall TabActive(int TabIndex);
	
public:
	__fastcall virtual TsuiTab(Classes::TComponent* AOwner);
	__fastcall virtual ~TsuiTab(void);
	virtual void __fastcall UpdateUIStyle(Suithemes::TsuiUIStyle UIStyle, Suimgr::TsuiFileTheme* FileTheme);
	__property DockManager;
	
__published:
	__property Align = {default=0};
	__property Suimgr::TsuiFileTheme* FileTheme = {read=m_FileTheme, write=SetFileTheme};
	__property Suithemes::TsuiUIStyle UIStyle = {read=m_UIStyle, write=SetUIStyle, nodefault};
	__property int LeftMargin = {read=GetLeftMargin, write=SetLeftMargin, nodefault};
	__property Graphics::TColor BorderColor = {read=m_BorderColor, write=SetBorderColor, nodefault};
	__property Color = {default=-16777201};
	__property Graphics::TFont* Font = {read=m_Font, write=SetFont};
	__property Visible = {default=1};
	__property TsuiTabPosition TabPosition = {read=m_TabPosition, write=SetTabPosition, nodefault};
	__property Imglist::TCustomImageList* Images = {read=m_ImageList, write=SetImageList};
	__property bool PageDrawFocused = {read=m_PageDrawFocused, write=SetPageDrawFocused, nodefault};
	__property Anchors = {default=3};
	__property BiDiMode;
	__property Constraints;
	__property UseDockManager = {default=1};
	__property DockSite = {default=0};
	__property DragCursor = {default=-12};
	__property DragKind = {default=0};
	__property DragMode = {default=0};
	__property Enabled = {default=1};
	__property FullRepaint = {default=1};
	__property Locked = {default=0};
	__property ParentBiDiMode = {default=1};
	__property ParentColor = {default=0};
	__property ParentCtl3D = {default=1};
	__property ParentFont = {default=1};
	__property ParentShowHint = {default=1};
	__property PopupMenu;
	__property ShowHint;
	__property TabOrder = {default=-1};
	__property TabStop = {default=0};
	__property OnCanResize;
	__property OnClick;
	__property OnConstrainedResize;
	__property OnContextPopup;
	__property OnDockDrop;
	__property OnDockOver;
	__property OnDblClick;
	__property OnDragDrop;
	__property OnDragOver;
	__property OnEndDock;
	__property OnEndDrag;
	__property OnEnter;
	__property OnExit;
	__property OnGetSiteInfo;
	__property OnMouseDown;
	__property OnMouseMove;
	__property OnMouseUp;
	__property OnResize;
	__property OnStartDock;
	__property OnStartDrag;
	__property OnUnDock;
	__property TTabActiveNotify OnTabActive = {read=m_OnTabActive, write=m_OnTabActive};
	__property Classes::TNotifyEvent OnChange = {read=m_OnChange, write=m_OnChange};
	__property Comctrls::TTabChangingEvent OnChanging = {read=m_OnChanging, write=m_OnChanging};
public:
	/* TWinControl.CreateParented */ inline __fastcall TsuiTab(HWND ParentWindow) : Extctrls::TCustomPanel(ParentWindow) { }
	
};


class DELPHICLASS TsuiTabControl;
class PASCALIMPLEMENTATION TsuiTabControl : public TsuiTab
{
	typedef TsuiTab inherited;
	
protected:
	virtual TsuiTabControlTopPanel* __fastcall CreateTopPanel(void);
	virtual int __fastcall GetImageIndex(int PageId);
	
__published:
	__property Tabs;
	__property TabIndex;
public:
	/* TsuiTab.Create */ inline __fastcall virtual TsuiTabControl(Classes::TComponent* AOwner) : TsuiTab(AOwner) { }
	/* TsuiTab.Destroy */ inline __fastcall virtual ~TsuiTabControl(void) { }
	
public:
	/* TWinControl.CreateParented */ inline __fastcall TsuiTabControl(HWND ParentWindow) : TsuiTab(ParentWindow) { }
	
};


//-- var, const, procedure ---------------------------------------------------
static const ShortInt SUI_TABCONTROL_MAXTABS = 0x40;

}	/* namespace Suitabcontrol */
using namespace Suitabcontrol;
#pragma pack(pop)
#pragma option pop

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// SuitabcontrolHPP
