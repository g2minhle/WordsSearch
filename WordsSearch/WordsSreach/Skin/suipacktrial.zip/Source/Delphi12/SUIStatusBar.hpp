// CodeGear C++Builder
// Copyright (c) 1995, 2008 by CodeGear
// All rights reserved

// (DO NOT EDIT: machine generated header) 'Suistatusbar.pas' rev: 20.00

#ifndef SuistatusbarHPP
#define SuistatusbarHPP

#pragma delphiheader begin
#pragma option push
#pragma option -w-      // All warnings off
#pragma option -Vx      // Zero-length empty class member functions
#pragma pack(push,8)
#include <System.hpp>	// Pascal unit
#include <Sysinit.hpp>	// Pascal unit
#include <Windows.hpp>	// Pascal unit
#include <Comctrls.hpp>	// Pascal unit
#include <Graphics.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <Forms.hpp>	// Pascal unit
#include <Controls.hpp>	// Pascal unit
#include <Messages.hpp>	// Pascal unit
#include <Suithemes.hpp>	// Pascal unit
#include <Suimgr.hpp>	// Pascal unit
#include <Sui2define.hpp>	// Pascal unit
#include <Menus.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Suistatusbar
{
//-- type declarations -------------------------------------------------------
class DELPHICLASS TsuiStatusBar;
class PASCALIMPLEMENTATION TsuiStatusBar : public Comctrls::TCustomStatusBar
{
	typedef Comctrls::TCustomStatusBar inherited;
	
private:
	Suithemes::TsuiUIStyle m_UIStyle;
	Suimgr::TsuiFileTheme* m_FileTheme;
	void __fastcall SetFileTheme(const Suimgr::TsuiFileTheme* Value);
	void __fastcall SetUIStyle(const Suithemes::TsuiUIStyle Value);
	Graphics::TColor __fastcall GetPanelColor(void);
	void __fastcall SetPanelColor(const Graphics::TColor Value);
	HIDESBASE MESSAGE void __fastcall WMPaint(Messages::TMessage &Msg);
	HIDESBASE MESSAGE void __fastcall WMNCHITTEST(Messages::TMessage &Msg);
	
protected:
	virtual void __fastcall Notification(Classes::TComponent* AComponent, Classes::TOperation Operation);
	
public:
	__fastcall virtual TsuiStatusBar(Classes::TComponent* AOwner);
	
__published:
	__property Suimgr::TsuiFileTheme* FileTheme = {read=m_FileTheme, write=SetFileTheme};
	__property Suithemes::TsuiUIStyle UIStyle = {read=m_UIStyle, write=SetUIStyle, nodefault};
	__property Graphics::TColor PanelColor = {read=GetPanelColor, write=SetPanelColor, nodefault};
	__property Action;
	__property AutoHint = {default=0};
	__property Align = {default=2};
	__property Anchors = {default=3};
	__property BiDiMode;
	__property BorderWidth = {default=0};
	__property Color = {default=-16777201};
	__property DragCursor = {default=-12};
	__property DragKind = {default=0};
	__property DragMode = {default=0};
	__property Enabled = {default=1};
	__property Font = {stored=IsFontStored};
	__property Constraints;
	__property Panels;
	__property ParentBiDiMode = {default=1};
	__property ParentColor = {default=0};
	__property ParentFont = {default=0};
	__property ParentShowHint = {default=1};
	__property PopupMenu;
	__property ShowHint;
	__property SimplePanel = {default=0};
	__property SimpleText;
	__property SizeGrip = {default=1};
	__property UseSystemFont = {default=1};
	__property Visible = {default=1};
	__property OnClick;
	__property OnContextPopup;
	__property OnCreatePanelClass;
	__property OnDblClick;
	__property OnDragDrop;
	__property OnDragOver;
	__property OnEndDock;
	__property OnEndDrag;
	__property OnHint;
	__property OnMouseDown;
	__property OnMouseMove;
	__property OnMouseUp;
	__property OnResize;
	__property OnStartDock;
	__property OnStartDrag;
	__property OnDrawPanel;
public:
	/* TCustomStatusBar.Destroy */ inline __fastcall virtual ~TsuiStatusBar(void) { }
	
public:
	/* TWinControl.CreateParented */ inline __fastcall TsuiStatusBar(HWND ParentWindow) : Comctrls::TCustomStatusBar(ParentWindow) { }
	
};


//-- var, const, procedure ---------------------------------------------------

}	/* namespace Suistatusbar */
using namespace Suistatusbar;
#pragma pack(pop)
#pragma option pop

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// SuistatusbarHPP
