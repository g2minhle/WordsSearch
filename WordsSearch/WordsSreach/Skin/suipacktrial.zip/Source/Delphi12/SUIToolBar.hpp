// CodeGear C++Builder
// Copyright (c) 1995, 2008 by CodeGear
// All rights reserved

// (DO NOT EDIT: machine generated header) 'Suitoolbar.pas' rev: 20.00

#ifndef SuitoolbarHPP
#define SuitoolbarHPP

#pragma delphiheader begin
#pragma option push
#pragma option -w-      // All warnings off
#pragma option -Vx      // Zero-length empty class member functions
#pragma pack(push,8)
#include <System.hpp>	// Pascal unit
#include <Sysinit.hpp>	// Pascal unit
#include <Windows.hpp>	// Pascal unit
#include <Messages.hpp>	// Pascal unit
#include <Sysutils.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <Controls.hpp>	// Pascal unit
#include <Toolwin.hpp>	// Pascal unit
#include <Comctrls.hpp>	// Pascal unit
#include <Graphics.hpp>	// Pascal unit
#include <Forms.hpp>	// Pascal unit
#include <Imglist.hpp>	// Pascal unit
#include <Suiform.hpp>	// Pascal unit
#include <Suithemes.hpp>	// Pascal unit
#include <Suimgr.hpp>	// Pascal unit
#include <Sui2define.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Suitoolbar
{
//-- type declarations -------------------------------------------------------
class DELPHICLASS TsuiToolBar;
class PASCALIMPLEMENTATION TsuiToolBar : public Comctrls::TToolBar
{
	typedef Comctrls::TToolBar inherited;
	
private:
	Suithemes::TsuiUIStyle m_UIStyle;
	Suimgr::TsuiFileTheme* m_FileTheme;
	Graphics::TColor m_ButtonColor;
	Graphics::TColor m_ButtonBorderColor;
	Graphics::TColor m_ButtonDownColor;
	Graphics::TColor m_BarColor;
	Graphics::TColor m_BarToColor;
	void __fastcall DrawBar(Comctrls::TToolBar* Sender, const Types::TRect &ARect, bool &DefaultDraw);
	void __fastcall DrawButton(Comctrls::TToolBar* Sender, Comctrls::TToolButton* Button, Comctrls::TCustomDrawState State, bool &DefaultDraw);
	void __fastcall DrawDownButton(Graphics::TCanvas* ACanvas, const Types::TRect &ARect, Imglist::TCustomImageList* ImgLst, int ImageIndex, Controls::TCaption Caption, bool DropDown);
	void __fastcall DrawHotButton(Graphics::TCanvas* ACanvas, const Types::TRect &ARect, Imglist::TCustomImageList* ImgLst, int ImageIndex, Controls::TCaption Caption, bool DropDown);
	void __fastcall SetUIStyle(const Suithemes::TsuiUIStyle Value);
	void __fastcall SetButtonBorderColor(const Graphics::TColor Value);
	void __fastcall SetButtonColor(const Graphics::TColor Value);
	void __fastcall SetButtonDownColor(const Graphics::TColor Value);
	void __fastcall SetFileTheme(const Suimgr::TsuiFileTheme* Value);
	
protected:
	virtual void __fastcall Notification(Classes::TComponent* AComponent, Classes::TOperation Operation);
	
public:
	__fastcall virtual TsuiToolBar(Classes::TComponent* AOwner);
	
__published:
	__property Suimgr::TsuiFileTheme* FileTheme = {read=m_FileTheme, write=SetFileTheme};
	__property Suithemes::TsuiUIStyle UIStyle = {read=m_UIStyle, write=SetUIStyle, nodefault};
	__property Graphics::TColor ButtonColor = {read=m_ButtonColor, write=SetButtonColor, nodefault};
	__property Graphics::TColor ButtonBorderColor = {read=m_ButtonBorderColor, write=SetButtonBorderColor, nodefault};
	__property Graphics::TColor ButtonDownColor = {read=m_ButtonDownColor, write=SetButtonDownColor, nodefault};
	__property Color = {default=-16777211};
	__property Transparent;
public:
	/* TToolBar.Destroy */ inline __fastcall virtual ~TsuiToolBar(void) { }
	
public:
	/* TWinControl.CreateParented */ inline __fastcall TsuiToolBar(HWND ParentWindow) : Comctrls::TToolBar(ParentWindow) { }
	
};


//-- var, const, procedure ---------------------------------------------------

}	/* namespace Suitoolbar */
using namespace Suitoolbar;
#pragma pack(pop)
#pragma option pop

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// SuitoolbarHPP
