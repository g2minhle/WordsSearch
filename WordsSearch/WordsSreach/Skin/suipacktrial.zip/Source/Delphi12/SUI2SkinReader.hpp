// CodeGear C++Builder
// Copyright (c) 1995, 2008 by CodeGear
// All rights reserved

// (DO NOT EDIT: machine generated header) 'Sui2skinreader.pas' rev: 20.00

#ifndef Sui2skinreaderHPP
#define Sui2skinreaderHPP

#pragma delphiheader begin
#pragma option push
#pragma option -w-      // All warnings off
#pragma option -Vx      // Zero-length empty class member functions
#pragma pack(push,8)
#include <System.hpp>	// Pascal unit
#include <Sysinit.hpp>	// Pascal unit
#include <Windows.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <Sysutils.hpp>	// Pascal unit
#include <Graphics.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Sui2skinreader
{
//-- type declarations -------------------------------------------------------
class DELPHICLASS Tsk2SkinFileReader;
class PASCALIMPLEMENTATION Tsk2SkinFileReader : public System::TObject
{
	typedef System::TObject inherited;
	
private:
	Classes::TStrings* m_BitmapList;
	Classes::TStrings* m_IntegerList;
	Classes::TStrings* m_BooleanList;
	Classes::TStrings* m_StrList;
	bool m_Ready;
	void __fastcall Load(System::UnicodeString FileName, System::UnicodeString Password);
	
public:
	__fastcall Tsk2SkinFileReader(System::UnicodeString FileName, System::UnicodeString Password);
	__fastcall virtual ~Tsk2SkinFileReader(void);
	Graphics::TBitmap* __fastcall GetBitmap(System::UnicodeString Key);
	int __fastcall GetInteger(System::UnicodeString Key);
	bool __fastcall GetBool(System::UnicodeString Key);
	System::UnicodeString __fastcall GetStr(System::UnicodeString Key);
	void __fastcall SetInteger(System::UnicodeString Key, int Value);
	void __fastcall SetBool(System::UnicodeString Key, bool Value);
	void __fastcall SetBitmap(System::UnicodeString Key, const Graphics::TBitmap* Buf);
	void __fastcall ProcessTransparentColor(Graphics::TColor TransColor);
	__property bool Ready = {read=m_Ready, nodefault};
};


//-- var, const, procedure ---------------------------------------------------

}	/* namespace Sui2skinreader */
using namespace Sui2skinreader;
#pragma pack(pop)
#pragma option pop

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// Sui2skinreaderHPP
