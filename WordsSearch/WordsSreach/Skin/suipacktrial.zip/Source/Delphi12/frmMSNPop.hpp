// CodeGear C++Builder
// Copyright (c) 1995, 2008 by CodeGear
// All rights reserved

// (DO NOT EDIT: machine generated header) 'Frmmsnpop.pas' rev: 20.00

#ifndef FrmmsnpopHPP
#define FrmmsnpopHPP

#pragma delphiheader begin
#pragma option push
#pragma option -w-      // All warnings off
#pragma option -Vx      // Zero-length empty class member functions
#pragma pack(push,8)
#include <System.hpp>	// Pascal unit
#include <Sysinit.hpp>	// Pascal unit
#include <Windows.hpp>	// Pascal unit
#include <Messages.hpp>	// Pascal unit
#include <Sysutils.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <Graphics.hpp>	// Pascal unit
#include <Controls.hpp>	// Pascal unit
#include <Forms.hpp>	// Pascal unit
#include <Dialogs.hpp>	// Pascal unit
#include <Extctrls.hpp>	// Pascal unit
#include <Stdctrls.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Frmmsnpop
{
//-- type declarations -------------------------------------------------------
class DELPHICLASS TfrmMSNPopForm;
class PASCALIMPLEMENTATION TfrmMSNPopForm : public Forms::TForm
{
	typedef Forms::TForm inherited;
	
__published:
	Extctrls::TTimer* Timer1;
	Stdctrls::TLabel* lbl_title;
	Stdctrls::TLabel* lbl_text;
	void __fastcall FormCreate(System::TObject* Sender);
	void __fastcall FormDestroy(System::TObject* Sender);
	void __fastcall FormShow(System::TObject* Sender);
	void __fastcall FormHide(System::TObject* Sender);
	void __fastcall Timer1Timer(System::TObject* Sender);
	void __fastcall FormClick(System::TObject* Sender);
	void __fastcall FormMouseDown(System::TObject* Sender, Controls::TMouseButton Button, Classes::TShiftState Shift, int X, int Y);
	
private:
	Graphics::TBitmap* m_Buf;
	unsigned m_Start;
	bool m_QuickHide;
	
protected:
	DYNAMIC void __fastcall Paint(void);
	virtual void __fastcall CreateParams(Controls::TCreateParams &Param);
	HIDESBASE MESSAGE void __fastcall WMPRINTCLIENT(Messages::TMessage &Msg);
	
public:
	int AnimateTime;
	int StayTime;
	bool ClickHide;
	Classes::TNotifyEvent CloseCallback;
public:
	/* TCustomForm.Create */ inline __fastcall virtual TfrmMSNPopForm(Classes::TComponent* AOwner) : Forms::TForm(AOwner) { }
	/* TCustomForm.CreateNew */ inline __fastcall virtual TfrmMSNPopForm(Classes::TComponent* AOwner, int Dummy) : Forms::TForm(AOwner, Dummy) { }
	/* TCustomForm.Destroy */ inline __fastcall virtual ~TfrmMSNPopForm(void) { }
	
public:
	/* TWinControl.CreateParented */ inline __fastcall TfrmMSNPopForm(HWND ParentWindow) : Forms::TForm(ParentWindow) { }
	
};


//-- var, const, procedure ---------------------------------------------------
extern PACKAGE TfrmMSNPopForm* frmMSNPopForm;

}	/* namespace Frmmsnpop */
using namespace Frmmsnpop;
#pragma pack(pop)
#pragma option pop

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// FrmmsnpopHPP
