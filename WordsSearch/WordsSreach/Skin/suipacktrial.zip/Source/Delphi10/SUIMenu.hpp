// Borland C++ Builder
// Copyright (c) 1995, 2005 by Borland Software Corporation
// All rights reserved

// (DO NOT EDIT: machine generated header) 'Suimenu.pas' rev: 10.00

#ifndef SuimenuHPP
#define SuimenuHPP

#pragma delphiheader begin
#pragma option push
#pragma option -w-      // All warnings off
#pragma option -Vx      // Zero-length empty class member functions
#pragma pack(push,8)
#include <System.hpp>	// Pascal unit
#include <Sysinit.hpp>	// Pascal unit
#include <Windows.hpp>	// Pascal unit
#include <Graphics.hpp>	// Pascal unit
#include <Menus.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Suimenu
{
//-- type declarations -------------------------------------------------------
//-- var, const, procedure ---------------------------------------------------
extern PACKAGE void __fastcall Menu_SetItemEvent(Menus::TMenuItem* MenuItem, Menus::TMenuDrawItemEvent DrawItemEvent, Menus::TMenuMeasureItemEvent MeasureItemEvent);
extern PACKAGE void __fastcall Menu_DrawBorder(Graphics::TCanvas* ACanvas, const Types::TRect &ARect, Graphics::TColor Color);
extern PACKAGE void __fastcall Menu_DrawBackGround(Graphics::TCanvas* ACanvas, const Types::TRect &ARect, Graphics::TColor Color);
extern PACKAGE void __fastcall Menu_DrawLineItem(Graphics::TCanvas* ACanvas, const Types::TRect &ARect, Graphics::TColor LineColor, int BarWidth, bool L2R);
extern PACKAGE void __fastcall Menu_DrawMacOSLineItem(Graphics::TCanvas* ACanvas, const Types::TRect &ARect);
extern PACKAGE void __fastcall Menu_DrawMacOSSelectedItem(Graphics::TCanvas* ACanvas, const Types::TRect &ARect);
extern PACKAGE void __fastcall Menu_DrawMacOSNonSelectedItem(Graphics::TCanvas* ACanvas, const Types::TRect &ARect);
extern PACKAGE void __fastcall Menu_DrawWindowBorder(HWND HandleOfWnd, Graphics::TColor BorderColor, Graphics::TColor FormColor);
extern PACKAGE void __fastcall Menu_GetSystemFont(const Graphics::TFont* Font);

}	/* namespace Suimenu */
using namespace Suimenu;
#pragma pack(pop)
#pragma option pop

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// Suimenu
