// Borland C++ Builder
// Copyright (c) 1995, 2005 by Borland Software Corporation
// All rights reserved

// (DO NOT EDIT: machine generated header) 'Suiscrollbar.pas' rev: 10.00

#ifndef SuiscrollbarHPP
#define SuiscrollbarHPP

#pragma delphiheader begin
#pragma option push
#pragma option -w-      // All warnings off
#pragma option -Vx      // Zero-length empty class member functions
#pragma pack(push,8)
#include <System.hpp>	// Pascal unit
#include <Sysinit.hpp>	// Pascal unit
#include <Windows.hpp>	// Pascal unit
#include <Extctrls.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <Controls.hpp>	// Pascal unit
#include <Sysutils.hpp>	// Pascal unit
#include <Graphics.hpp>	// Pascal unit
#include <Forms.hpp>	// Pascal unit
#include <Messages.hpp>	// Pascal unit
#include <Math.hpp>	// Pascal unit
#include <Suiprogressbar.hpp>	// Pascal unit
#include <Suitrackbar.hpp>	// Pascal unit
#include <Suibutton.hpp>	// Pascal unit
#include <Suithemes.hpp>	// Pascal unit
#include <Suimgr.hpp>	// Pascal unit
#include <Sui2define.hpp>	// Pascal unit
#include <Menus.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Suiscrollbar
{
//-- type declarations -------------------------------------------------------
class DELPHICLASS TsuiScrollBar;
class PASCALIMPLEMENTATION TsuiScrollBar : public Extctrls::TCustomPanel 
{
	typedef Extctrls::TCustomPanel inherited;
	
private:
	Suitrackbar::TsuiScrollTrackBar* m_TrackBar;
	Suibutton::TsuiImageButton* m_Btn1;
	Suibutton::TsuiImageButton* m_Btn2;
	Graphics::TBitmap* m_SliderLeft;
	Graphics::TBitmap* m_SliderCenter;
	Graphics::TBitmap* m_SliderRight;
	Suithemes::TsuiUIStyle m_UIStyle;
	Suimgr::TsuiFileTheme* m_FileTheme;
	Suiprogressbar::TsuiProgressBarOrientation m_Orientation;
	Forms::TScrollBarInc m_SmallChange;
	int m_LineButton;
	void __fastcall SetOrientation(const Suiprogressbar::TsuiProgressBarOrientation Value);
	void __fastcall SetUIStyle(const Suithemes::TsuiUIStyle Value);
	void __fastcall PlaceTrackBarAndButton(void);
	void __fastcall UpdatePictures(void);
	void __fastcall UpdateSliderPic(void);
	int __fastcall GetMax(void);
	int __fastcall GetMin(void);
	int __fastcall GetPosition(void);
	void __fastcall SetMax(const int Value);
	void __fastcall SetMin(const int Value);
	void __fastcall SetPosition(const int Value);
	Forms::TScrollBarInc __fastcall GetLargeChange(void);
	void __fastcall SetLargeChange(const Forms::TScrollBarInc Value);
	int __fastcall GetPageSize(void);
	void __fastcall SetPageSize(const int Value);
	bool __fastcall GetSliderVisible(void);
	void __fastcall SetSliderVisible(const bool Value);
	Classes::TNotifyEvent __fastcall GetOnChange();
	void __fastcall SetOnChange(const Classes::TNotifyEvent Value);
	void __fastcall SetFileTheme(const Suimgr::TsuiFileTheme* Value);
	void __fastcall MouseContinuouslyDownDec(System::TObject* Sender);
	void __fastcall MouseContinuouslyDownInc(System::TObject* Sender);
	HIDESBASE MESSAGE void __fastcall WMSIZE(Messages::TMessage &Msg);
	HIDESBASE MESSAGE void __fastcall WMERASEBKGND(Messages::TMessage &Msg);
	HIDESBASE MESSAGE void __fastcall CMColorChanged(Messages::TMessage &Message);
	HIDESBASE MESSAGE void __fastcall CMVisibleChanged(Messages::TMessage &Message);
	void __fastcall SetLineButton(const int Value);
	int __fastcall GetLastChange(void);
	
protected:
	DYNAMIC void __fastcall Resize(void);
	virtual void __fastcall Notification(Classes::TComponent* AComponent, Classes::TOperation Operation);
	
public:
	__fastcall virtual TsuiScrollBar(Classes::TComponent* AOwner);
	__fastcall virtual ~TsuiScrollBar(void);
	__property bool SliderVisible = {read=GetSliderVisible, write=SetSliderVisible, nodefault};
	__property int LastChange = {read=GetLastChange, nodefault};
	
__published:
	__property Suimgr::TsuiFileTheme* FileTheme = {read=m_FileTheme, write=SetFileTheme};
	__property int LineButton = {read=m_LineButton, write=SetLineButton, nodefault};
	__property Suiprogressbar::TsuiProgressBarOrientation Orientation = {read=m_Orientation, write=SetOrientation, nodefault};
	__property Suithemes::TsuiUIStyle UIStyle = {read=m_UIStyle, write=SetUIStyle, nodefault};
	__property int Max = {read=GetMax, write=SetMax, nodefault};
	__property int Min = {read=GetMin, write=SetMin, nodefault};
	__property int Position = {read=GetPosition, write=SetPosition, nodefault};
	__property Forms::TScrollBarInc SmallChange = {read=m_SmallChange, write=m_SmallChange, nodefault};
	__property Forms::TScrollBarInc LargeChange = {read=GetLargeChange, write=SetLargeChange, nodefault};
	__property int PageSize = {read=GetPageSize, write=SetPageSize, nodefault};
	__property Align  = {default=0};
	__property Anchors  = {default=3};
	__property BiDiMode ;
	__property Color  = {default=-16777201};
	__property Constraints ;
	__property DragCursor  = {default=-12};
	__property DragKind  = {default=0};
	__property DragMode  = {default=0};
	__property Enabled  = {default=1};
	__property ParentBiDiMode  = {default=1};
	__property ParentColor  = {default=0};
	__property ParentShowHint  = {default=1};
	__property PopupMenu ;
	__property ShowHint ;
	__property Visible  = {default=1};
	__property Classes::TNotifyEvent OnChange = {read=GetOnChange, write=SetOnChange};
	__property OnContextPopup ;
	__property OnDragDrop ;
	__property OnDragOver ;
	__property OnEndDock ;
	__property OnEndDrag ;
	__property OnEnter ;
	__property OnExit ;
	__property OnStartDock ;
	__property OnStartDrag ;
public:
	#pragma option push -w-inl
	/* TWinControl.CreateParented */ inline __fastcall TsuiScrollBar(HWND ParentWindow) : Extctrls::TCustomPanel(ParentWindow) { }
	#pragma option pop
	
};


//-- var, const, procedure ---------------------------------------------------

}	/* namespace Suiscrollbar */
using namespace Suiscrollbar;
#pragma pack(pop)
#pragma option pop

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// Suiscrollbar
