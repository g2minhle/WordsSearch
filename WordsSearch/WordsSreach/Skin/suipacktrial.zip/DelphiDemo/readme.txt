The MDI demo project uses a TsuiBuiltInFileTheme component to build the
skin into the EXE file. So the EXE can be runned with skinned without
skin file.

When you open the project by Delphi, since the location of the skin file
is not same between ours and yours. Before run the project, you should
re-specify the ThemeFile property of TsuiBuiltInFileTheme component. Or
the form will come with the default skin - DeepBlue.