// Borland C++ Builder
// Copyright (c) 1995, 2005 by Borland Software Corporation
// All rights reserved

// (DO NOT EDIT: machine generated header) 'Skin2skinreader.pas' rev: 10.00

#ifndef Skin2skinreaderHPP
#define Skin2skinreaderHPP

#pragma delphiheader begin
#pragma option push
#pragma option -w-      // All warnings off
#pragma option -Vx      // Zero-length empty class member functions
#pragma pack(push,8)
#include <System.hpp>	// Pascal unit
#include <Sysinit.hpp>	// Pascal unit
#include <Windows.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <Sysutils.hpp>	// Pascal unit
#include <Graphics.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Skin2skinreader
{
//-- type declarations -------------------------------------------------------
class DELPHICLASS Tsk2SkinFileReader;
class PASCALIMPLEMENTATION Tsk2SkinFileReader : public System::TObject 
{
	typedef System::TObject inherited;
	
private:
	Classes::TStrings* m_BitmapList;
	Classes::TStrings* m_IntegerList;
	Classes::TStrings* m_BooleanList;
	Classes::TStrings* m_StrList;
	void __fastcall Load(AnsiString FileName, AnsiString Password);
	
public:
	__fastcall Tsk2SkinFileReader(AnsiString FileName, AnsiString Password);
	__fastcall virtual ~Tsk2SkinFileReader(void);
	Graphics::TBitmap* __fastcall GetBitmap(AnsiString Key);
	int __fastcall GetInteger(AnsiString Key);
	bool __fastcall GetBool(AnsiString Key);
	AnsiString __fastcall GetStr(AnsiString Key);
	void __fastcall SetInteger(AnsiString Key, int Value);
	void __fastcall SetBool(AnsiString Key, bool Value);
	void __fastcall SetBitmap(AnsiString Key, const Graphics::TBitmap* Buf);
	void __fastcall ProcessTransparentColor(Graphics::TColor TransColor);
};


//-- var, const, procedure ---------------------------------------------------

}	/* namespace Skin2skinreader */
using namespace Skin2skinreader;
#pragma pack(pop)
#pragma option pop

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// Skin2skinreader
