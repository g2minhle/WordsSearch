// Borland C++ Builder
// Copyright (c) 1995, 2005 by Borland Software Corporation
// All rights reserved

// (DO NOT EDIT: machine generated header) 'Suiskinstdwnd.pas' rev: 10.00

#ifndef SuiskinstdwndHPP
#define SuiskinstdwndHPP

#pragma delphiheader begin
#pragma option push
#pragma option -w-      // All warnings off
#pragma option -Vx      // Zero-length empty class member functions
#pragma pack(push,8)
#include <System.hpp>	// Pascal unit
#include <Sysinit.hpp>	// Pascal unit
#include <Windows.hpp>	// Pascal unit
#include <Messages.hpp>	// Pascal unit
#include <Graphics.hpp>	// Pascal unit
#include <Sysutils.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <Extctrls.hpp>	// Pascal unit
#include <Math.hpp>	// Pascal unit
#include <Commctrl.hpp>	// Pascal unit
#include <Suiskinengine.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Suiskinstdwnd
{
//-- type declarations -------------------------------------------------------
class DELPHICLASS TsuiSkinWndComboBox;
class PASCALIMPLEMENTATION TsuiSkinWndComboBox : public Suiskinengine::TsuiSkinBorderWndControl 
{
	typedef Suiskinengine::TsuiSkinBorderWndControl inherited;
	
protected:
	virtual void __fastcall PaintControl(void);
public:
	#pragma option push -w-inl
	/* TsuiSkinControlWnd.Create */ inline __fastcall TsuiSkinWndComboBox(unsigned CtrlWnd, Suiskinengine::TsuiSkinWindow* SkinWnd) : Suiskinengine::TsuiSkinBorderWndControl(CtrlWnd, SkinWnd) { }
	#pragma option pop
	#pragma option push -w-inl
	/* TsuiSkinControlWnd.Destroy */ inline __fastcall virtual ~TsuiSkinWndComboBox(void) { }
	#pragma option pop
	
};


class DELPHICLASS TsuiSkinWndButton;
class PASCALIMPLEMENTATION TsuiSkinWndButton : public Suiskinengine::TsuiSkinControlWnd 
{
	typedef Suiskinengine::TsuiSkinControlWnd inherited;
	
private:
	bool m_Downed;
	Extctrls::TTimer* m_Timer;
	bool m_Painted;
	void __fastcall OnTimer(System::TObject* Sender);
	
protected:
	virtual bool __fastcall BeforeDefProc(Messages::TMessage &Message);
	virtual void __fastcall PaintControl(void);
	virtual void __fastcall AfterDefProc(Messages::TMessage &Message);
	virtual void __fastcall MouseUp(void);
	virtual void __fastcall MouseDown(void);
	virtual void __fastcall DoInit(void);
	virtual void __fastcall DoUninit(void);
public:
	#pragma option push -w-inl
	/* TsuiSkinControlWnd.Create */ inline __fastcall TsuiSkinWndButton(unsigned CtrlWnd, Suiskinengine::TsuiSkinWindow* SkinWnd) : Suiskinengine::TsuiSkinControlWnd(CtrlWnd, SkinWnd) { }
	#pragma option pop
	#pragma option push -w-inl
	/* TsuiSkinControlWnd.Destroy */ inline __fastcall virtual ~TsuiSkinWndButton(void) { }
	#pragma option pop
	
};


class DELPHICLASS TsuiSkinWndCheckBox;
class PASCALIMPLEMENTATION TsuiSkinWndCheckBox : public Suiskinengine::TsuiSkinControlWnd 
{
	typedef Suiskinengine::TsuiSkinControlWnd inherited;
	
private:
	unsigned m_Style;
	
protected:
	virtual void __fastcall DoInit(void);
	virtual void __fastcall PaintControl(void);
	virtual void __fastcall AfterDefProc(Messages::TMessage &Message);
public:
	#pragma option push -w-inl
	/* TsuiSkinControlWnd.Create */ inline __fastcall TsuiSkinWndCheckBox(unsigned CtrlWnd, Suiskinengine::TsuiSkinWindow* SkinWnd) : Suiskinengine::TsuiSkinControlWnd(CtrlWnd, SkinWnd) { }
	#pragma option pop
	#pragma option push -w-inl
	/* TsuiSkinControlWnd.Destroy */ inline __fastcall virtual ~TsuiSkinWndCheckBox(void) { }
	#pragma option pop
	
};


class DELPHICLASS TsuiSkinWndRadioButton;
class PASCALIMPLEMENTATION TsuiSkinWndRadioButton : public Suiskinengine::TsuiSkinControlWnd 
{
	typedef Suiskinengine::TsuiSkinControlWnd inherited;
	
protected:
	virtual void __fastcall PaintControl(void);
	virtual void __fastcall AfterDefProc(Messages::TMessage &Message);
public:
	#pragma option push -w-inl
	/* TsuiSkinControlWnd.Create */ inline __fastcall TsuiSkinWndRadioButton(unsigned CtrlWnd, Suiskinengine::TsuiSkinWindow* SkinWnd) : Suiskinengine::TsuiSkinControlWnd(CtrlWnd, SkinWnd) { }
	#pragma option pop
	#pragma option push -w-inl
	/* TsuiSkinControlWnd.Destroy */ inline __fastcall virtual ~TsuiSkinWndRadioButton(void) { }
	#pragma option pop
	
};


class DELPHICLASS TsuiSkinWndTabControl;
class PASCALIMPLEMENTATION TsuiSkinWndTabControl : public Suiskinengine::TsuiSkinControlWnd 
{
	typedef Suiskinengine::TsuiSkinControlWnd inherited;
	
private:
	int m_OldTabHeight;
	void __fastcall PaintPage(const Graphics::TBitmap* Buf, int PageIndex, const Types::TRect &R, bool Active);
	
protected:
	virtual void __fastcall DoInit(void);
	virtual void __fastcall ActiveChanged(void);
	virtual bool __fastcall BeforeDefProc(Messages::TMessage &Message);
	virtual void __fastcall PaintControl(void);
public:
	#pragma option push -w-inl
	/* TsuiSkinControlWnd.Create */ inline __fastcall TsuiSkinWndTabControl(unsigned CtrlWnd, Suiskinengine::TsuiSkinWindow* SkinWnd) : Suiskinengine::TsuiSkinControlWnd(CtrlWnd, SkinWnd) { }
	#pragma option pop
	#pragma option push -w-inl
	/* TsuiSkinControlWnd.Destroy */ inline __fastcall virtual ~TsuiSkinWndTabControl(void) { }
	#pragma option pop
	
};


class DELPHICLASS TsuiSkinWndToolbarWindow32;
class PASCALIMPLEMENTATION TsuiSkinWndToolbarWindow32 : public Suiskinengine::TsuiSkinControlWnd 
{
	typedef Suiskinengine::TsuiSkinControlWnd inherited;
	
protected:
	virtual void __fastcall DoInit(void);
public:
	#pragma option push -w-inl
	/* TsuiSkinControlWnd.Create */ inline __fastcall TsuiSkinWndToolbarWindow32(unsigned CtrlWnd, Suiskinengine::TsuiSkinWindow* SkinWnd) : Suiskinengine::TsuiSkinControlWnd(CtrlWnd, SkinWnd) { }
	#pragma option pop
	#pragma option push -w-inl
	/* TsuiSkinControlWnd.Destroy */ inline __fastcall virtual ~TsuiSkinWndToolbarWindow32(void) { }
	#pragma option pop
	
};


//-- var, const, procedure ---------------------------------------------------
extern PACKAGE Suiskinengine::TsuiSkinCtrlWndDef SUISKIN_STDCTRLSWND_DEF[7];

}	/* namespace Suiskinstdwnd */
using namespace Suiskinstdwnd;
#pragma pack(pop)
#pragma option pop

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// Suiskinstdwnd
