// CodeGear C++Builder
// Copyright (c) 1995, 2008 by CodeGear
// All rights reserved

// (DO NOT EDIT: machine generated header) 'Suiskinengine.pas' rev: 20.00

#ifndef SuiskinengineHPP
#define SuiskinengineHPP

#pragma delphiheader begin
#pragma option push
#pragma option -w-      // All warnings off
#pragma option -Vx      // Zero-length empty class member functions
#pragma pack(push,8)
#include <System.hpp>	// Pascal unit
#include <Sysinit.hpp>	// Pascal unit
#include <Windows.hpp>	// Pascal unit
#include <Messages.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <Forms.hpp>	// Pascal unit
#include <Sysutils.hpp>	// Pascal unit
#include <Controls.hpp>	// Pascal unit
#include <Math.hpp>	// Pascal unit
#include <Graphics.hpp>	// Pascal unit
#include <Menus.hpp>	// Pascal unit
#include <Comctrls.hpp>	// Pascal unit
#include <Extctrls.hpp>	// Pascal unit
#include <Appevnts.hpp>	// Pascal unit
#include <Imglist.hpp>	// Pascal unit
#include <Typinfo.hpp>	// Pascal unit
#include <Dialogs.hpp>	// Pascal unit
#include <Stdctrls.hpp>	// Pascal unit
#include <Mask.hpp>	// Pascal unit
#include <Grids.hpp>	// Pascal unit
#include <Suiskinutils.hpp>	// Pascal unit
#include <Skin2define.hpp>	// Pascal unit
#include <Toolwin.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Suiskinengine
{
//-- type declarations -------------------------------------------------------
class DELPHICLASS TsuiSkinEngine;
class DELPHICLASS TsuiSkinWindow;
class DELPHICLASS TsuiSkinCollection;
class PASCALIMPLEMENTATION TsuiSkinEngine : public Classes::TComponent
{
	typedef Classes::TComponent inherited;
	
private:
	bool m_Active;
	Classes::TList* m_WndList;
	Suiskinutils::TsuiSkinReader* m_SkinReader;
	Suiskinutils::TsuiSkinReader* m_MainReader;
	System::UnicodeString m_SkinFile;
	System::UnicodeString m_Password;
	Menus::TPopupMenu* m_InternalSysMenu;
	Menus::TPopupMenu* m_CustomSysMenu;
	TsuiSkinWindow* m_PopSysMenuWnd;
	Suiskinutils::TsuiSkinScrollBtnRes* m_ScrollBtnRes;
	Suiskinutils::TsuiSkinProgressBarRes* m_ProgressBarRes;
	Suiskinutils::TsuiSkinTabRes* m_TabRes;
	bool m_BuiltIn;
	bool m_SkinDialogs;
	bool m_SkinAllForms;
	bool m_DoingAllForms;
	TsuiSkinCollection* m_AdditionalBuiltInSkins;
	Classes::TNotifyEvent m_OnSkinChanged;
	Classes::TNotifyEvent m_OnSkinChanging;
	unsigned m_Brush;
	bool m_RemovingWnd;
	Classes::TStrings* m_AutoSkinWndClassNames;
	Graphics::TColor m_DisabledMenuFontColor;
	Graphics::TColor m_FormFrameColor;
	int m_TitleHeight;
	int m_LeftBorderWidth;
	int m_RightBorderWidth;
	int m_BottomBorderWidth;
	Graphics::TColor m_TransColor;
	Graphics::TColor m_FormColor;
	Types::TPoint m_TitleIconPos;
	Types::TPoint m_TitleBtnPos;
	int m_TitleCaptionTop;
	int m_TitleFontColor;
	Graphics::TColor m_InactiveTitleFontColor;
	StaticArray<Graphics::TColor, 13> m_MenuColors;
	int m_AllFormCaptionXPos;
	bool m_DrawSpeedButtonAsBitBtn;
	System::UnicodeString m_ResSysMenuMin;
	System::UnicodeString m_ResSysMenuMax;
	System::UnicodeString m_ResSysMenuClose;
	int m_DisabledTag;
	bool m_DrawScrollBar;
	int m_TitleRegionMin;
	int m_TitleRegionMax;
	int m_BottomRegionMin;
	int m_BottomRegionMax;
	int m_MinWidth;
	bool m_BtnNeedAltKey;
	bool m_NoChangeButtonsFontColor;
	bool m_NoChangeLabelFontColor;
	void __fastcall SetActive(const bool Value);
	bool __fastcall GetRealActive(void);
	bool __fastcall GetReady(void);
	Graphics::TColor __fastcall GetMenuBarColor(void);
	System::UnicodeString __fastcall GetVersion();
	void __fastcall SetBuiltIn(const bool Value);
	void __fastcall SetVersion(const System::UnicodeString Value);
	void __fastcall SetReady(const bool Value);
	void __fastcall SetSkinFile(const System::UnicodeString Value);
	Menus::TPopupMenu* __fastcall GetSysMenu(void);
	void __fastcall SetSysMenu(const Menus::TPopupMenu* Value);
	void __fastcall SetResSysMenuClose(const System::UnicodeString Value);
	void __fastcall SetResSysMenuMax(const System::UnicodeString Value);
	void __fastcall SetResSysMenuMin(const System::UnicodeString Value);
	void __fastcall SetDrawScrollBar(const bool Value);
	void __fastcall SetAdditionalBuiltInSkins(const TsuiSkinCollection* Value);
	void __fastcall SetSkinAllForms(const bool Value);
	int __fastcall GetSkinnedFormsCount(void);
	void __fastcall DoAddWnd(unsigned hWnd, bool ForDialog);
	void __fastcall DoRemoveWnd(unsigned hWnd);
	void __fastcall ReadSkinData(Classes::TStream* Stream);
	void __fastcall WriteSkinData(Classes::TStream* Stream);
	void __fastcall OnInternalSkinChanged(System::TObject* Sender);
	void __fastcall OnMin(System::TObject* Sender);
	void __fastcall OnMax(System::TObject* Sender);
	void __fastcall OnClose(System::TObject* Sender);
	void __fastcall OnSysMenuPopup(System::TObject* Sender);
	void __fastcall OnAutoSkinWndClassNamesChange(System::TObject* Sender);
	void __fastcall InitMenu(Menus::TMenu* Menu);
	void __fastcall UnInitMenu(Menus::TMenu* Menu);
	void __fastcall InitMenuItem(Menus::TMenuItem* MenuItem);
	void __fastcall UnInitMenuItem(Menus::TMenuItem* MenuItem);
	void __fastcall DrawPopMenuItem(System::TObject* Sender, Graphics::TCanvas* ACanvas, const Types::TRect &ARect, bool Selected);
	void __fastcall MeasurePopMenuItem(System::TObject* Sender, Graphics::TCanvas* ACanvas, int &Width, int &Height);
	System::UnicodeString __fastcall GetBuild();
	void __fastcall SetAutoSkinWndClassNames(const Classes::TStrings* Value);
	
protected:
	virtual void __fastcall Loaded(void);
	virtual void __fastcall DefineProperties(Classes::TFiler* Filer);
	virtual void __fastcall Notification(Classes::TComponent* AComponent, Classes::TOperation Operation);
	
public:
	__fastcall virtual TsuiSkinEngine(Classes::TComponent* AOwner);
	__fastcall virtual ~TsuiSkinEngine(void);
	bool __fastcall GetBitmap(Skin2define::Tsk2SkinBitmapElement Key, const Graphics::TBitmap* Buf, int SpitCount = 0x0, int SpitIndex = 0x0);
	Graphics::TColor __fastcall GetColor(Skin2define::Tsk2SkinColorElement Key);
	int __fastcall GetInteger(Skin2define::Tsk2IntElement Key);
	bool __fastcall GetBool(Skin2define::Tsk2BoolElement Key);
	Graphics::TColor __fastcall GetFormColor(void);
	void __fastcall BeginUpdateControl(Controls::TControl* Ctrl);
	void __fastcall EndUpdateControl(Controls::TControl* Ctrl);
	void __fastcall AddControl(Controls::TControl* Ctrl);
	void __fastcall RemoveControl(Controls::TControl* Ctrl);
	void __fastcall UpdateTopMenu(void)/* overload */;
	void __fastcall UpdateTopMenu(Forms::TCustomForm* Form)/* overload */;
	void __fastcall ApplyCaptionXPos(const Forms::TCustomForm* Form, int CaptionXPos);
	void __fastcall ApplyCaptionXPosForAll(int CaptionXPos);
	void __fastcall AssignMainMenu(Menus::TMainMenu* Menu)/* overload */;
	void __fastcall AssignMainMenu(Forms::TCustomForm* Form, Menus::TMainMenu* Menu)/* overload */;
	int __fastcall GetMenuBarHeight(Forms::TCustomForm* Form);
	void __fastcall MenuItemAdded(Menus::TMenu* Menu);
	void __fastcall AddForm(Forms::TCustomForm* Form);
	void __fastcall AddForm_BCB(Forms::TCustomForm* Form);
	void __fastcall RemoveForm(Forms::TCustomForm* Form);
	void __fastcall ApplyAdditionalBuiltInSkins(int Index);
	void __fastcall ApplyMainBuiltInSkin(void);
	void __fastcall AddWindow(unsigned hWnd);
	void __fastcall RemoveWindow(unsigned hWnd);
	void __fastcall DoSkinAllForms(void);
	void __fastcall UnskinOtherForms(void);
	__property bool RealActive = {read=GetRealActive, nodefault};
	__property int TitleHeight = {read=m_TitleHeight, nodefault};
	__property Graphics::TColor MenuBarColor = {read=GetMenuBarColor, nodefault};
	__property Graphics::TColor FormFrameColor = {read=m_FormFrameColor, write=m_FormFrameColor, nodefault};
	__property Menus::TPopupMenu* SysMenu = {read=GetSysMenu, write=SetSysMenu};
	__property Suiskinutils::TsuiSkinScrollBtnRes* ScrollBtnRes = {read=m_ScrollBtnRes};
	__property Suiskinutils::TsuiSkinProgressBarRes* ProgressBarRes = {read=m_ProgressBarRes};
	__property Suiskinutils::TsuiSkinTabRes* TabRes = {read=m_TabRes};
	__property int SkinnedFormsCount = {read=GetSkinnedFormsCount, nodefault};
	__property Graphics::TColor TransparentColor = {read=m_TransColor, nodefault};
	__property Graphics::TColor DisabledMenuFontColor = {read=m_DisabledMenuFontColor, write=m_DisabledMenuFontColor, nodefault};
	__property Graphics::TColor InactiveTitleFontColor = {read=m_InactiveTitleFontColor, write=m_InactiveTitleFontColor, nodefault};
	__property bool DrawSpeedButtonAsBitBtn = {read=m_DrawSpeedButtonAsBitBtn, write=m_DrawSpeedButtonAsBitBtn, nodefault};
	__property bool __BtnNeedAltKey = {read=m_BtnNeedAltKey, write=m_BtnNeedAltKey, nodefault};
	__property System::UnicodeString __Build = {read=GetBuild};
	
__published:
	__property bool Active = {read=m_Active, write=SetActive, nodefault};
	__property bool Ready = {read=GetReady, write=SetReady, nodefault};
	__property System::UnicodeString Password = {read=m_Password, write=m_Password};
	__property System::UnicodeString SkinFile = {read=m_SkinFile, write=SetSkinFile};
	__property System::UnicodeString ResSysMenuMin = {read=m_ResSysMenuMin, write=SetResSysMenuMin};
	__property System::UnicodeString ResSysMenuMax = {read=m_ResSysMenuMax, write=SetResSysMenuMax};
	__property System::UnicodeString ResSysMenuClose = {read=m_ResSysMenuClose, write=SetResSysMenuClose};
	__property int DisabledTag = {read=m_DisabledTag, write=m_DisabledTag, nodefault};
	__property bool DrawScrollBar = {read=m_DrawScrollBar, write=SetDrawScrollBar, nodefault};
	__property System::UnicodeString Version = {read=GetVersion, write=SetVersion};
	__property bool BuiltIn = {read=m_BuiltIn, write=SetBuiltIn, nodefault};
	__property bool SkinDialogs = {read=m_SkinDialogs, write=m_SkinDialogs, nodefault};
	__property bool SkinAllForms = {read=m_SkinAllForms, write=SetSkinAllForms, nodefault};
	__property TsuiSkinCollection* AdditionalBuiltInSkins = {read=m_AdditionalBuiltInSkins, write=SetAdditionalBuiltInSkins};
	__property bool NoChangeButtonsFontColor = {read=m_NoChangeButtonsFontColor, write=m_NoChangeButtonsFontColor, nodefault};
	__property bool NoChangeLabelFontColor = {read=m_NoChangeLabelFontColor, write=m_NoChangeLabelFontColor, nodefault};
	__property Classes::TStrings* AutoSkinWndClassNames = {read=m_AutoSkinWndClassNames, write=SetAutoSkinWndClassNames};
	__property Classes::TNotifyEvent OnSkinChanged = {read=m_OnSkinChanged, write=m_OnSkinChanged};
	__property Classes::TNotifyEvent OnSkinChanging = {read=m_OnSkinChanging, write=m_OnSkinChanging};
};


class DELPHICLASS TsuiSkinCollectionItem;
class PASCALIMPLEMENTATION TsuiSkinCollectionItem : public Classes::TCollectionItem
{
	typedef Classes::TCollectionItem inherited;
	
private:
	System::UnicodeString m_SkinFile;
	System::UnicodeString m_Password;
	Suiskinutils::TsuiSkinReader* m_Reader;
	void __fastcall ReadSkinData(Classes::TStream* Stream);
	void __fastcall WriteSkinData(Classes::TStream* Stream);
	
protected:
	virtual void __fastcall DefineProperties(Classes::TFiler* Filer);
	
public:
	__fastcall virtual TsuiSkinCollectionItem(Classes::TCollection* Collection);
	__fastcall virtual ~TsuiSkinCollectionItem(void);
	
__published:
	__property System::UnicodeString SkinFile = {read=m_SkinFile, write=m_SkinFile};
	__property System::UnicodeString Password = {read=m_Password, write=m_Password};
};


class PASCALIMPLEMENTATION TsuiSkinCollection : public Classes::TCollection
{
	typedef Classes::TCollection inherited;
	
private:
	TsuiSkinEngine* m_SkinEngine;
	
protected:
	HIDESBASE TsuiSkinCollectionItem* __fastcall GetItem(int Index);
	HIDESBASE void __fastcall SetItem(int Index, TsuiSkinCollectionItem* Value);
	virtual void __fastcall Update(Classes::TCollectionItem* Item);
	DYNAMIC Classes::TPersistent* __fastcall GetOwner(void);
	
public:
	__fastcall TsuiSkinCollection(TsuiSkinEngine* SkinEngine);
	__fastcall virtual ~TsuiSkinCollection(void);
	HIDESBASE TsuiSkinCollectionItem* __fastcall Add(void);
	__property TsuiSkinCollectionItem* Items[int Index] = {read=GetItem, write=SetItem};
};


#pragma option push -b-
enum TsuiSkinControlMouseState { suiSkinMouseIn, suiSkinMouseDown };
#pragma option pop

class DELPHICLASS TsuiSkinControl;
class PASCALIMPLEMENTATION TsuiSkinControl : public System::TObject
{
	typedef System::TObject inherited;
	
protected:
	TsuiSkinWindow* m_SkinWnd;
	TsuiSkinEngine* m_Engine;
	Set<TsuiSkinControlMouseState, suiSkinMouseIn, suiSkinMouseDown>  m_MouseState;
	bool m_Destroying;
	virtual bool __fastcall BeforeDefProc(Messages::TMessage &Message);
	virtual void __fastcall AfterDefProc(Messages::TMessage &Message);
	virtual void __fastcall PaintControl(void);
	virtual void __fastcall MouseEnter(void);
	virtual void __fastcall MouseExit(void);
	virtual void __fastcall MouseDown(void);
	virtual void __fastcall MouseUp(void);
	virtual void __fastcall KeyDown(int VKey);
	virtual void __fastcall KeyUp(int VKey);
	virtual void __fastcall ActiveChanged(void);
	virtual void __fastcall DoInit(void);
	virtual void __fastcall DoUninit(void);
	virtual Types::TRect __fastcall GetClientRect(void) = 0 ;
	virtual unsigned __fastcall GetHandle(void) = 0 ;
	virtual bool __fastcall Enabled(void) = 0 ;
	
public:
	void __fastcall PaintBG(Graphics::TBitmap* Buf, System::UnicodeString Caption, const Graphics::TFont* Font, const Types::TRect &TextRect, bool WordWrap);
	void __fastcall PaintBGW(Graphics::TBitmap* Buf, System::WideString Caption, const Graphics::TFont* Font, const Types::TRect &TextRect, bool WordWrap);
	void __fastcall PaintBitmap(Graphics::TBitmap* Buf, const Types::TPoint &Position);
	__fastcall virtual ~TsuiSkinControl(void);
	virtual bool __fastcall ParentColor(void);
public:
	/* TObject.Create */ inline __fastcall TsuiSkinControl(void) : System::TObject() { }
	
};


class DELPHICLASS TsuiSkinControlVCL;
class PASCALIMPLEMENTATION TsuiSkinControlVCL : public TsuiSkinControl
{
	typedef TsuiSkinControl inherited;
	
private:
	Classes::TWndMethod m_OldWndProc;
	void __fastcall NewWndProc(Messages::TMessage &Message);
	
protected:
	Controls::TControl* m_Control;
	virtual Types::TRect __fastcall GetClientRect();
	virtual bool __fastcall Enabled(void);
	virtual unsigned __fastcall GetHandle(void);
	
public:
	__fastcall TsuiSkinControlVCL(Controls::TControl* WinCtrl, TsuiSkinWindow* SkinWnd);
	__fastcall virtual ~TsuiSkinControlVCL(void);
};


class DELPHICLASS TsuiSkinControlWnd;
class PASCALIMPLEMENTATION TsuiSkinControlWnd : public TsuiSkinControl
{
	typedef TsuiSkinControl inherited;
	
private:
	void *m_OldWndProc;
	void *m_NewWndProc;
	void __fastcall NewWndProc(Messages::TMessage &Message);
	
protected:
	unsigned m_CtrlWnd;
	virtual Types::TRect __fastcall GetClientRect();
	virtual bool __fastcall Enabled(void);
	unsigned __fastcall GetEngineBrush(void);
	virtual unsigned __fastcall GetHandle(void);
	int __fastcall GetWidth(void);
	int __fastcall GetHeight(void);
	System::UnicodeString __fastcall GetText();
	
public:
	__fastcall TsuiSkinControlWnd(unsigned CtrlWnd, TsuiSkinWindow* SkinWnd);
	__fastcall virtual ~TsuiSkinControlWnd(void);
};


class DELPHICLASS TsuiSkinBorderWinControl;
class PASCALIMPLEMENTATION TsuiSkinBorderWinControl : public TsuiSkinControlVCL
{
	typedef TsuiSkinControlVCL inherited;
	
protected:
	virtual void __fastcall PaintControl(void);
public:
	/* TsuiSkinControlVCL.Create */ inline __fastcall TsuiSkinBorderWinControl(Controls::TControl* WinCtrl, TsuiSkinWindow* SkinWnd) : TsuiSkinControlVCL(WinCtrl, SkinWnd) { }
	/* TsuiSkinControlVCL.Destroy */ inline __fastcall virtual ~TsuiSkinBorderWinControl(void) { }
	
};


class DELPHICLASS TsuiSkinBorderWndControl;
class PASCALIMPLEMENTATION TsuiSkinBorderWndControl : public TsuiSkinControlWnd
{
	typedef TsuiSkinControlWnd inherited;
	
protected:
	virtual void __fastcall PaintControl(void);
public:
	/* TsuiSkinControlWnd.Create */ inline __fastcall TsuiSkinBorderWndControl(unsigned CtrlWnd, TsuiSkinWindow* SkinWnd) : TsuiSkinControlWnd(CtrlWnd, SkinWnd) { }
	/* TsuiSkinControlWnd.Destroy */ inline __fastcall virtual ~TsuiSkinBorderWndControl(void) { }
	
};


class DELPHICLASS TsuiSkinExtComboboxLikeControl;
class DELPHICLASS TsuiSkinInternalComboButton;
class PASCALIMPLEMENTATION TsuiSkinExtComboboxLikeControl : public TsuiSkinBorderWinControl
{
	typedef TsuiSkinBorderWinControl inherited;
	
protected:
	TsuiSkinInternalComboButton* m_Btn;
	virtual void __fastcall AfterDefProc(Messages::TMessage &Message);
	virtual void __fastcall PaintControl(void);
	virtual void __fastcall ActiveChanged(void);
	virtual void __fastcall DoInit(void);
	virtual void __fastcall DoUninit(void);
public:
	/* TsuiSkinControlVCL.Create */ inline __fastcall TsuiSkinExtComboboxLikeControl(Controls::TControl* WinCtrl, TsuiSkinWindow* SkinWnd) : TsuiSkinBorderWinControl(WinCtrl, SkinWnd) { }
	/* TsuiSkinControlVCL.Destroy */ inline __fastcall virtual ~TsuiSkinExtComboboxLikeControl(void) { }
	
};


class PASCALIMPLEMENTATION TsuiSkinInternalComboButton : public Extctrls::TCustomPanel
{
	typedef Extctrls::TCustomPanel inherited;
	
private:
	Controls::TWinControl* m_Ctrl;
	TsuiSkinExtComboboxLikeControl* m_SkinCtrl;
	HIDESBASE MESSAGE void __fastcall WMLBUTTONDOWN(Messages::TMessage &Msg);
	HIDESBASE MESSAGE void __fastcall WMLBUTTONUP(Messages::TMessage &Msg);
	HIDESBASE MESSAGE void __fastcall WMERASEBKGND(Messages::TMessage &Msg);
	
protected:
	virtual void __fastcall Paint(void);
	
public:
	__fastcall virtual TsuiSkinInternalComboButton(Classes::TComponent* AOwner);
	__fastcall virtual ~TsuiSkinInternalComboButton(void);
public:
	/* TWinControl.CreateParented */ inline __fastcall TsuiSkinInternalComboButton(HWND ParentWindow) : Extctrls::TCustomPanel(ParentWindow) { }
	
};


class DELPHICLASS TsuiSkinInternalScrollBar;
class DELPHICLASS TsuiSkinScrollWinControl;
class PASCALIMPLEMENTATION TsuiSkinInternalScrollBar : public Extctrls::TCustomPanel
{
	typedef Extctrls::TCustomPanel inherited;
	
private:
	Controls::TWinControl* m_Ctrl;
	Graphics::TBitmap* m_Buf;
	TsuiSkinScrollWinControl* m_SkinCtrl;
	int m_Type;
	HIDESBASE MESSAGE void __fastcall WMLBUTTONDOWN(Messages::TMessage &Msg);
	HIDESBASE MESSAGE void __fastcall WMLBUTTONUP(Messages::TMessage &Msg);
	HIDESBASE MESSAGE void __fastcall WMERASEBKGND(Messages::TMessage &Msg);
	HIDESBASE MESSAGE void __fastcall WMLBUTTONDBLCLK(Messages::TMessage &Msg);
	
protected:
	virtual void __fastcall Paint(void);
	
public:
	__fastcall virtual TsuiSkinInternalScrollBar(Classes::TComponent* AOwner);
	__fastcall virtual ~TsuiSkinInternalScrollBar(void);
public:
	/* TWinControl.CreateParented */ inline __fastcall TsuiSkinInternalScrollBar(HWND ParentWindow) : Extctrls::TCustomPanel(ParentWindow) { }
	
};


class PASCALIMPLEMENTATION TsuiSkinScrollWinControl : public TsuiSkinBorderWinControl
{
	typedef TsuiSkinBorderWinControl inherited;
	
private:
	TsuiSkinInternalScrollBar* m_VScroll;
	TsuiSkinInternalScrollBar* m_HScroll;
	void __fastcall PaintScroll(void);
	
protected:
	virtual void __fastcall AfterDefProc(Messages::TMessage &Message);
	virtual void __fastcall PaintControl(void);
	virtual void __fastcall ActiveChanged(void);
	virtual void __fastcall DoInit(void);
	virtual void __fastcall DoUninit(void);
public:
	/* TsuiSkinControlVCL.Create */ inline __fastcall TsuiSkinScrollWinControl(Controls::TControl* WinCtrl, TsuiSkinWindow* SkinWnd) : TsuiSkinBorderWinControl(WinCtrl, SkinWnd) { }
	/* TsuiSkinControlVCL.Destroy */ inline __fastcall virtual ~TsuiSkinScrollWinControl(void) { }
	
};


#pragma option push -b-
enum TsuiSkinTabPos { stTop, stBottom, stLeft, stRight };
#pragma option pop

class DELPHICLASS TsuiSkinTabLikeControl;
class PASCALIMPLEMENTATION TsuiSkinTabLikeControl : public TsuiSkinControlVCL
{
	typedef TsuiSkinControlVCL inherited;
	
private:
	void __fastcall PaintPage(const Graphics::TBitmap* Buf, const Graphics::TFont* Font, TsuiSkinTabPos TabPos, int PageIndex, const Types::TRect &R, bool Active);
	
protected:
	virtual System::UnicodeString __fastcall GetPageText(int Index) = 0 ;
	virtual Types::TRect __fastcall GetTabRect(int Index) = 0 ;
	virtual int __fastcall GetPageCount(void) = 0 ;
	virtual Types::TRect __fastcall GetPageRect(void) = 0 ;
	virtual int __fastcall GetCurPageIndex(void) = 0 ;
	virtual Graphics::TFont* __fastcall GetFont(void) = 0 ;
	virtual TsuiSkinTabPos __fastcall GetTabPos(void) = 0 ;
	virtual Graphics::TCanvas* __fastcall GetCanvas(void) = 0 ;
	virtual void __fastcall PaintControl(void);
public:
	/* TsuiSkinControlVCL.Create */ inline __fastcall TsuiSkinTabLikeControl(Controls::TControl* WinCtrl, TsuiSkinWindow* SkinWnd) : TsuiSkinControlVCL(WinCtrl, SkinWnd) { }
	/* TsuiSkinControlVCL.Destroy */ inline __fastcall virtual ~TsuiSkinTabLikeControl(void) { }
	
};


class PASCALIMPLEMENTATION TsuiSkinWindow : public Classes::TComponent
{
	typedef Classes::TComponent inherited;
	
protected:
	TsuiSkinEngine* m_Engine;
	bool m_TitleVisible;
	bool m_BorderVisible;
	bool m_Destroying;
	bool m_Creating;
	Graphics::TBitmap* m_TitleBufRgn;
	Graphics::TBitmap* m_TitleBuf;
	Graphics::TBitmap* m_BottomBufRgn;
	Graphics::TBitmap* m_BottomBuf;
	int m_ClientHeight;
	int m_ClientWidth;
	bool m_ForDialog;
	Classes::TList* m_SkinCtrlList;
	bool m_CanMax;
	bool m_DrawMax;
	bool m_DrawMin;
	bool m_DrawClose;
	int m_InButtons;
	bool m_NCMouseDown;
	bool m_FormActive;
	bool m_Active;
	bool m_SavedWndStyle;
	bool m_MaxFlag;
	bool m_DrawForm;
	bool m_TitleNeedRegion;
	bool m_BottomNeedRegion;
	int m_TitleBtnLeft;
	int m_CaptionXPos;
	void __fastcall SetActive(const bool Value);
	System::UnicodeString __fastcall GetCaption();
	int __fastcall GetWidth(void);
	int __fastcall GetHeight(void);
	void __fastcall SetTitleVisible(const bool Value);
	int __fastcall GetTitleHeight(void);
	void __fastcall SetBorderVisible(const bool Value);
	void __fastcall NewWndProc(Messages::TMessage &Msg);
	void __fastcall DoMax(void);
	void __fastcall DoMin(void);
	void __fastcall DoClose(void);
	void __fastcall DoSysMenu(void)/* overload */;
	void __fastcall DoSysMenu(const Types::TPoint &P)/* overload */;
	void __fastcall DoHelp(void);
	void __fastcall SaveWndStyle(void);
	int m_OldTitleHeight;
	int m_OldBottomHeight;
	int m_OldLeftBorderWidth;
	int m_OldLeftBorderWidth2;
	int m_OldBottomHeight2;
	int m_EmptyTitle;
	void __fastcall RegionWindow(void);
	void __fastcall PaintTitle(void);
	virtual System::WideString __fastcall GetWideCaption();
	virtual void __fastcall ActiveChanged(void) = 0 ;
	virtual void __fastcall CallDefaultWndProc(Messages::TMessage &Msg) = 0 ;
	virtual void __fastcall DoSaveWndStyle(void);
	virtual void __fastcall InitControls(void) = 0 ;
	virtual void __fastcall UnInitControls(void) = 0 ;
	virtual bool __fastcall CanRegionWindow(void);
	virtual int __fastcall GetMenuHeight(void);
	virtual unsigned __fastcall GetHasFormIcon(void);
	virtual bool __fastcall GetDrawHelpButton(void);
	virtual bool __fastcall GetIsMDIForm(void);
	virtual bool __fastcall GetIsMDIChild(void);
	virtual bool __fastcall GetIsDialog(void);
	virtual bool __fastcall DrawControlBox(void);
	virtual bool __fastcall DrawCloseButton(void);
	virtual bool __fastcall DrawMaxButton(void);
	virtual bool __fastcall DrawMinButton(void);
	virtual bool __fastcall CanSaveWndStyle(void);
	virtual bool __fastcall GetHasToolBar(void);
	virtual bool __fastcall GetIsVCL(void);
	virtual unsigned __fastcall GetHandle(void) = 0 ;
	virtual void __fastcall UnskinnedSizing(void);
	virtual bool __fastcall BeforeDefaultWndProc(Messages::TMessage &Msg);
	virtual void __fastcall AfterDefaultWndProc(Messages::TMessage &Msg);
	virtual void __fastcall Init(unsigned hWnd) = 0 ;
	virtual void __fastcall Uninit(void) = 0 ;
	
public:
	__fastcall TsuiSkinWindow(unsigned hWnd, TsuiSkinEngine* Engine, bool ForDialog);
	__fastcall virtual ~TsuiSkinWindow(void);
	void __fastcall SkinChanged(void);
	__property bool TitleVisible = {read=m_TitleVisible, write=SetTitleVisible, nodefault};
	__property bool BorderVisible = {read=m_BorderVisible, write=SetBorderVisible, nodefault};
	__property int TitleHeight = {read=GetTitleHeight, nodefault};
	__property int MenuHeight = {read=GetMenuHeight, nodefault};
};


class DELPHICLASS TsuiSkinMenuBar;
class DELPHICLASS TsuiSkinWindowVCL;
class PASCALIMPLEMENTATION TsuiSkinMenuBar : public Comctrls::TToolBar
{
	typedef Comctrls::TToolBar inherited;
	
private:
	TsuiSkinWindowVCL* m_SkinWnd;
	void __fastcall OnMenuPopup(System::TObject* Sender);
	HIDESBASE MESSAGE void __fastcall CMDialogChar(Messages::TWMKey &Message);
	
protected:
	virtual void __fastcall Notification(Classes::TComponent* AComponent, Classes::TOperation Operation);
	virtual void __fastcall WndProc(Messages::TMessage &Message);
public:
	/* TToolBar.Create */ inline __fastcall virtual TsuiSkinMenuBar(Classes::TComponent* AOwner) : Comctrls::TToolBar(AOwner) { }
	/* TToolBar.Destroy */ inline __fastcall virtual ~TsuiSkinMenuBar(void) { }
	
public:
	/* TWinControl.CreateParented */ inline __fastcall TsuiSkinMenuBar(HWND ParentWindow) : Comctrls::TToolBar(ParentWindow) { }
	
};


class DELPHICLASS TsuiSkinMenuBarControlButton;
class PASCALIMPLEMENTATION TsuiSkinMenuBarControlButton : public Extctrls::TCustomPanel
{
	typedef Extctrls::TCustomPanel inherited;
	
private:
	bool m_MouseIn;
	Graphics::TBitmap* m_Glyph;
	Graphics::TColor m_ToColor;
	MESSAGE void __fastcall MouseLeave(Messages::TMessage &Msg);
	MESSAGE void __fastcall MouseEnter(Messages::TMessage &Msg);
	void __fastcall SetGlyph(const Graphics::TBitmap* Value);
	HIDESBASE MESSAGE void __fastcall WMERASEBKGND(Messages::TMessage &Msg);
	
protected:
	virtual void __fastcall Paint(void);
	
public:
	__fastcall virtual TsuiSkinMenuBarControlButton(Classes::TComponent* AOwner);
	__fastcall virtual ~TsuiSkinMenuBarControlButton(void);
	
__published:
	__property Graphics::TBitmap* Glyph = {read=m_Glyph, write=SetGlyph};
	__property Color = {default=-16777201};
	__property Graphics::TColor ToColor = {read=m_ToColor, write=m_ToColor, nodefault};
	__property OnClick;
public:
	/* TWinControl.CreateParented */ inline __fastcall TsuiSkinMenuBarControlButton(HWND ParentWindow) : Extctrls::TCustomPanel(ParentWindow) { }
	
};


class PASCALIMPLEMENTATION TsuiSkinWindowVCL : public TsuiSkinWindow
{
	typedef TsuiSkinWindow inherited;
	
private:
	Forms::TForm* m_Form;
	Classes::TWndMethod m_OldWndProc;
	void *m_OldClientWndProc;
	Menus::TMainMenu* m_Menu;
	Menus::TMainMenu* m_MDIMenu;
	Menus::TMainMenu* m_LastMenu;
	Menus::TMainMenu* m_LastMDIMenu;
	Classes::TList* m_MergedTopMenuItems;
	TsuiSkinMenuBar* m_MenuBar;
	Graphics::TColor m_OldColor;
	StaticArray<TsuiSkinMenuBarControlButton*, 3> m_ControlBtns;
	Appevnts::TApplicationEvents* m_AppEvent;
	bool m_SkinAlled;
	bool m_SelfChanging;
	bool m_SelfChanging2;
	bool m_Moved;
	bool m_MinWidth;
	bool m_MinHeight;
	Classes::TList* m_WindowMenuList;
	bool m_HasToolbar;
	bool m_GotHasToolbar;
	bool m_Hidden;
	Graphics::TColor m_ControlBtnsColor;
	Graphics::TColor m_ControlBtnsToColor;
	bool m_SelfSizing;
	void __fastcall NewClientWndProc(Messages::TMessage &Msg);
	void __fastcall ReAssignClientWndProc(void);
	void __fastcall OnControlButtonClick(System::TObject* Sender);
	void __fastcall OnApplicationMessage(tagMSG &Msg, bool &Handled);
	void __fastcall DrawMenuButton(Comctrls::TToolBar* Sender, Comctrls::TToolButton* Button, Comctrls::TCustomDrawState State, bool &DefaultDraw);
	void __fastcall DrawMenuBar(Comctrls::TToolBar* Sender, const Types::TRect &ARect, bool &DefaultDraw);
	void __fastcall ProcessKeyPress(Messages::TMessage &Msg);
	void __fastcall OnWindowMenuClick(System::TObject* Sender);
	void __fastcall Cascade(void);
	void __fastcall Tile(bool Horizontal);
	void __fastcall RebuildMainMenu(bool Force);
	void __fastcall ShowMDIControlBtn(void);
	void __fastcall HideMDIControlBtn(void);
	void __fastcall ReplaceMDIControlBtn(void);
	void __fastcall UpdateMDITopMenu(Forms::TForm* Form, Menus::TMainMenu* Menu);
	void __fastcall RebuildWindowMenu(void);
	void __fastcall NotifyToRebuildWindowMenu(void);
	void __fastcall SetConstraints(void);
	void __fastcall CancelConstraints(void);
	void __fastcall InitMenus(void);
	void __fastcall UnInitMenus(void);
	void __fastcall InitControl(Controls::TControl* WinCtrl);
	void __fastcall UnInitControl(Controls::TControl* WinCtrl)/* overload */;
	void __fastcall UnInitControl(TsuiSkinControlVCL* WinCtrl)/* overload */;
	
protected:
	virtual void __fastcall DoSaveWndStyle(void);
	virtual void __fastcall ActiveChanged(void);
	virtual System::WideString __fastcall GetWideCaption();
	virtual bool __fastcall CanRegionWindow(void);
	virtual int __fastcall GetMenuHeight(void);
	virtual unsigned __fastcall GetHasFormIcon(void);
	virtual bool __fastcall GetDrawHelpButton(void);
	virtual bool __fastcall GetIsMDIForm(void);
	virtual bool __fastcall GetIsMDIChild(void);
	virtual bool __fastcall GetIsDialog(void);
	virtual bool __fastcall CanSaveWndStyle(void);
	virtual bool __fastcall DrawControlBox(void);
	virtual bool __fastcall DrawCloseButton(void);
	virtual bool __fastcall DrawMinButton(void);
	virtual bool __fastcall DrawMaxButton(void);
	virtual bool __fastcall GetHasToolBar(void);
	virtual unsigned __fastcall GetHandle(void);
	virtual bool __fastcall GetIsVCL(void);
	virtual void __fastcall UnskinnedSizing(void);
	virtual void __fastcall Init(unsigned hWnd);
	virtual void __fastcall Uninit(void);
	virtual void __fastcall InitControls(void);
	virtual void __fastcall UnInitControls(void);
	virtual void __fastcall CallDefaultWndProc(Messages::TMessage &Msg);
	virtual void __fastcall AfterDefaultWndProc(Messages::TMessage &Msg);
	virtual bool __fastcall BeforeDefaultWndProc(Messages::TMessage &Msg);
public:
	/* TsuiSkinWindow.Create */ inline __fastcall TsuiSkinWindowVCL(unsigned hWnd, TsuiSkinEngine* Engine, bool ForDialog) : TsuiSkinWindow(hWnd, Engine, ForDialog) { }
	/* TsuiSkinWindow.Destroy */ inline __fastcall virtual ~TsuiSkinWindowVCL(void) { }
	
};


class DELPHICLASS TsuiSkinWindowWnd;
class PASCALIMPLEMENTATION TsuiSkinWindowWnd : public TsuiSkinWindow
{
	typedef TsuiSkinWindow inherited;
	
private:
	unsigned m_hWnd;
	void *m_OldWndProc;
	void *m_NewWndProc;
	unsigned m_OldStyle;
	unsigned m_OldStyle2;
	bool m_SavedWndStyle2;
	bool m_Expanded;
	bool m_ProgressingWnd;
	bool m_OpenWnd;
	bool m_DirDlgWnd;
	void *m_CtmDlgWndProc;
	void *m_NewCtmDlgWndProc;
	unsigned m_CtmDlgWnd;
	void __fastcall InitControl(unsigned hWnd);
	void __fastcall UnInitControl(unsigned hWnd)/* overload */;
	void __fastcall UnInitControl(TsuiSkinControlWnd* SkinCtrl)/* overload */;
	void __fastcall NewCtmDlgWndProc(Messages::TMessage &Msg);
	void __fastcall CheckCustomDlg(void);
	
protected:
	virtual void __fastcall ActiveChanged(void);
	virtual void __fastcall DoSaveWndStyle(void);
	virtual void __fastcall CallDefaultWndProc(Messages::TMessage &Msg);
	virtual bool __fastcall BeforeDefaultWndProc(Messages::TMessage &Msg);
	virtual void __fastcall AfterDefaultWndProc(Messages::TMessage &Msg);
	virtual unsigned __fastcall GetHandle(void);
	virtual System::WideString __fastcall GetWideCaption();
	virtual void __fastcall Init(unsigned hWnd);
	virtual void __fastcall Uninit(void);
	virtual void __fastcall InitControls(void);
	virtual void __fastcall UnInitControls(void);
	
public:
	__property bool ProgressingWnd = {read=m_ProgressingWnd, nodefault};
public:
	/* TsuiSkinWindow.Create */ inline __fastcall TsuiSkinWindowWnd(unsigned hWnd, TsuiSkinEngine* Engine, bool ForDialog) : TsuiSkinWindow(hWnd, Engine, ForDialog) { }
	/* TsuiSkinWindow.Destroy */ inline __fastcall virtual ~TsuiSkinWindowWnd(void) { }
	
};


typedef TMetaClass* TsuiSkinControlVCLClass;

typedef TMetaClass* TsuiControlClass;

struct TsuiSkinCtrlVCLDef
{
	
public:
	TsuiControlClass CtrlClass;
	TsuiSkinControlVCLClass SkinCtrlClass;
};


typedef TMetaClass* TsuiSkinControlWndClass;

struct TsuiSkinCtrlWndDef
{
	
public:
	SmallString<64>  CtrlClass;
	TsuiSkinControlWndClass SkinCtrlClass;
};


typedef DynamicArray<TsuiSkinCtrlVCLDef> Suiskinengine__91;

typedef DynamicArray<TsuiSkinCtrlWndDef> Suiskinengine__02;

//-- var, const, procedure ---------------------------------------------------
#define SUISKIN_VERSION L"4.7"
#define SUISKIN_BUILD L"2009.3.12"
#define SUISKIN_SYSMENU_MINIMIZE L"Mi&nimize"
#define SUISKIN_SYSMENU_MAXIMIZE L"Ma&ximize/Restore"
#define SUISKIN_SYSMENU_CLOSE L"&Close"
static const Word SUIM_ACTIVED = 0x2aab;
static const Word SUIM_PAINTCONTROL = 0x2aac;
static const Word SUIM_PAINTTITLE = 0x2aad;
extern PACKAGE bool g_ShowMDIControlButtons;
extern PACKAGE Suiskinengine__91 g_CtrlClassDef;
extern PACKAGE Suiskinengine__02 g_CtrlClassDef2;
extern PACKAGE System::WideString g_DlgTitle;
static const bool SUISKIN_DELPHI12 = true;
extern PACKAGE void __fastcall RegisterSkinControlClass(TsuiSkinCtrlVCLDef *Defs, const int Defs_Size);
extern PACKAGE void __fastcall RegisterSkinControlClassWnd(TsuiSkinCtrlWndDef *Defs, const int Defs_Size);
extern PACKAGE void __fastcall RegisterBorderFilterClass(System::UnicodeString ClassName);
extern PACKAGE void __fastcall RegisterDisabledClass(System::UnicodeString ClassName);
extern PACKAGE void __fastcall RegisterDlgFormClass(System::UnicodeString ClassName);
extern PACKAGE void __fastcall DrawScrollbar(const Graphics::TCanvas* ACanvas, const TsuiSkinEngine* Engine, const Types::TRect &ARect, Forms::TScrollBarKind Kind, bool DrawSlider, const Types::TRect &SliderRect);
extern PACKAGE Graphics::TBitmap* __fastcall __InternalGetBitmap(const TsuiSkinEngine* SkinEngine, int Key);
extern PACKAGE void __fastcall __InternalGetBitmap2(const TsuiSkinEngine* SkinEngine, int Key, const Graphics::TBitmap* Buf, int SpitCount, int SpitIndex);
extern PACKAGE bool __fastcall __InternalGetBool(const TsuiSkinEngine* SkinEngine, int Key);
extern PACKAGE Graphics::TColor __fastcall __InternalGetColor(const TsuiSkinEngine* SkinEngine, int Key);
extern PACKAGE int __fastcall __InternalGetInt(const TsuiSkinEngine* SkinEngine, int Key);

}	/* namespace Suiskinengine */
using namespace Suiskinengine;
#pragma pack(pop)
#pragma option pop

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// SuiskinengineHPP
