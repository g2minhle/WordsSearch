// CodeGear C++Builder
// Copyright (c) 1995, 2008 by CodeGear
// All rights reserved

// (DO NOT EDIT: machine generated header) 'Suiskinutils.pas' rev: 20.00

#ifndef SuiskinutilsHPP
#define SuiskinutilsHPP

#pragma delphiheader begin
#pragma option push
#pragma option -w-      // All warnings off
#pragma option -Vx      // Zero-length empty class member functions
#pragma pack(push,8)
#include <System.hpp>	// Pascal unit
#include <Sysinit.hpp>	// Pascal unit
#include <Windows.hpp>	// Pascal unit
#include <Messages.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <Sysutils.hpp>	// Pascal unit
#include <Math.hpp>	// Pascal unit
#include <Graphics.hpp>	// Pascal unit
#include <Controls.hpp>	// Pascal unit
#include <Buttons.hpp>	// Pascal unit
#include <Typinfo.hpp>	// Pascal unit
#include <Forms.hpp>	// Pascal unit
#include <Menus.hpp>	// Pascal unit
#include <Imglist.hpp>	// Pascal unit
#include <Skin2skinreader.hpp>	// Pascal unit
#include <Skin2define.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Suiskinutils
{
//-- type declarations -------------------------------------------------------
class DELPHICLASS TsuiSkinReader;
class PASCALIMPLEMENTATION TsuiSkinReader : public System::TObject
{
	typedef System::TObject inherited;
	
private:
	Skin2skinreader::Tsk2SkinFileReader* m_SK2Reader;
	bool m_Ready;
	Classes::TNotifyEvent m_OnChanged;
	
public:
	__fastcall TsuiSkinReader(System::UnicodeString FileName, System::UnicodeString Password);
	__fastcall virtual ~TsuiSkinReader(void);
	Graphics::TBitmap* __fastcall GetBitmap(Skin2define::Tsk2SkinBitmapElement Key);
	int __fastcall GetInteger(Skin2define::Tsk2IntElement Key);
	Graphics::TColor __fastcall GetColor(Skin2define::Tsk2SkinColorElement Key);
	bool __fastcall GetBool(Skin2define::Tsk2BoolElement Key);
	void __fastcall SetInteger(Skin2define::Tsk2IntElement Key, int Value);
	void __fastcall SetBool(Skin2define::Tsk2BoolElement Key, bool Value);
	void __fastcall SetBitmap(Skin2define::Tsk2SkinBitmapElement Key, const Graphics::TBitmap* Buf);
	void __fastcall SetColor(Skin2define::Tsk2SkinColorElement Key, Graphics::TColor Value);
	void __fastcall LoadSkin(System::UnicodeString FileName, System::UnicodeString Password);
	__property bool Ready = {read=m_Ready, nodefault};
	__property Classes::TNotifyEvent OnChanged = {read=m_OnChanged, write=m_OnChanged};
};


class DELPHICLASS TsuiSkinRes;
class PASCALIMPLEMENTATION TsuiSkinRes : public System::TObject
{
	typedef System::TObject inherited;
	
private:
	bool __fastcall GetReady(void);
	
protected:
	TsuiSkinReader* m_SkinReader;
	virtual void __fastcall ReaderChanged(void);
	
public:
	void __fastcall SetReader(const TsuiSkinReader* SkinReader);
	__property bool Ready = {read=GetReady, nodefault};
public:
	/* TObject.Create */ inline __fastcall TsuiSkinRes(void) : System::TObject() { }
	/* TObject.Destroy */ inline __fastcall virtual ~TsuiSkinRes(void) { }
	
};


class DELPHICLASS TsuiSkinScrollBtnRes;
class PASCALIMPLEMENTATION TsuiSkinScrollBtnRes : public TsuiSkinRes
{
	typedef TsuiSkinRes inherited;
	
private:
	StaticArray<Graphics::TBitmap*, 6> m_H;
	StaticArray<Graphics::TBitmap*, 6> m_V;
	StaticArray<Graphics::TBitmap*, 5> m_HS;
	StaticArray<Graphics::TBitmap*, 5> m_VS;
	Graphics::TBitmap* m_FullHS;
	Graphics::TBitmap* m_FullVS;
	int m_SliderWidth;
	bool m_MacOS;
	
protected:
	virtual void __fastcall ReaderChanged(void);
	
public:
	__fastcall virtual ~TsuiSkinScrollBtnRes(void);
	Graphics::TBitmap* __fastcall GetHBtn(int Index);
	Graphics::TBitmap* __fastcall GetVBtn(int Index);
	Graphics::TBitmap* __fastcall GetHSlider(int Index);
	Graphics::TBitmap* __fastcall GetVSlider(int Index);
	__property int SliderWidth = {read=m_SliderWidth, nodefault};
	__property bool MacOS = {read=m_MacOS, nodefault};
	__property Graphics::TBitmap* FullHS = {read=m_FullHS};
	__property Graphics::TBitmap* FullVS = {read=m_FullVS};
public:
	/* TObject.Create */ inline __fastcall TsuiSkinScrollBtnRes(void) : TsuiSkinRes() { }
	
};


class DELPHICLASS TsuiSkinProgressBarRes;
class PASCALIMPLEMENTATION TsuiSkinProgressBarRes : public TsuiSkinRes
{
	typedef TsuiSkinRes inherited;
	
private:
	StaticArray<Graphics::TBitmap*, 4> m_H;
	StaticArray<Graphics::TBitmap*, 4> m_V;
	int m_BorderWidth1;
	int m_BorderWidth2;
	
protected:
	virtual void __fastcall ReaderChanged(void);
	
public:
	__fastcall virtual ~TsuiSkinProgressBarRes(void);
	Graphics::TBitmap* __fastcall GetH(int Index);
	Graphics::TBitmap* __fastcall GetV(int Index);
	__property int BorderWidth1 = {read=m_BorderWidth1, nodefault};
	__property int BorderWidth2 = {read=m_BorderWidth2, nodefault};
public:
	/* TObject.Create */ inline __fastcall TsuiSkinProgressBarRes(void) : TsuiSkinRes() { }
	
};


class DELPHICLASS TsuiSkinTabRes;
class PASCALIMPLEMENTATION TsuiSkinTabRes : public TsuiSkinRes
{
	typedef TsuiSkinRes inherited;
	
private:
	Graphics::TBitmap* m_B1;
	Graphics::TBitmap* m_B2;
	Graphics::TBitmap* m_B3;
	Graphics::TBitmap* m_B4;
	Graphics::TBitmap* m_P1;
	Graphics::TBitmap* m_P2;
	Graphics::TBitmap* m_P3;
	Graphics::TBitmap* m_P4;
	Graphics::TBitmap* m_A1;
	Graphics::TBitmap* m_A2;
	Graphics::TBitmap* m_A3;
	Graphics::TBitmap* m_a4;
	
protected:
	virtual void __fastcall ReaderChanged(void);
	
public:
	__fastcall virtual ~TsuiSkinTabRes(void);
	Graphics::TBitmap* __fastcall GetTopBar(void);
	Graphics::TBitmap* __fastcall GetLeftBar(void);
	Graphics::TBitmap* __fastcall GetBottomBar(void);
	Graphics::TBitmap* __fastcall GetRightBar(void);
	Graphics::TBitmap* __fastcall GetTopPage(bool Active);
	Graphics::TBitmap* __fastcall GetLeftPage(bool Active);
	Graphics::TBitmap* __fastcall GetBottomPage(bool Active);
	Graphics::TBitmap* __fastcall GetRightPage(bool Active);
public:
	/* TObject.Create */ inline __fastcall TsuiSkinTabRes(void) : TsuiSkinRes() { }
	
};


#pragma option push -b-
enum TsuiSkinVAlignType { suiSkinTop, suiSkinCenter, suiSkinBottom };
#pragma option pop

typedef void __fastcall (__closure *TsuiSkinBitBtnPainter)(const Graphics::TBitmap* Buf, /* out */ Types::TRect &TextRect);

//-- var, const, procedure ---------------------------------------------------
extern PACKAGE void __fastcall SetBitmapWindow(HWND HandleOfWnd, const Graphics::TBitmap* TitleBmp, const Graphics::TBitmap* BottomBmp, bool TitleNeedRegion, bool BottomNeedRegion, Graphics::TColor TitleMin, Graphics::TColor TitleMax, Graphics::TColor BottomMin, Graphics::TColor BottomMax, Graphics::TColor TransColor, int Height, int Width);
extern PACKAGE bool __stdcall SUISkinGetScrollBarInfo(HWND Handle, int idObject, tagSCROLLBARINFO &ScrollInfo);
extern PACKAGE bool __stdcall SUISkinGetComboBoxInfo(HWND hwndCombo, tagCOMBOBOXINFO &pcbi);
extern PACKAGE HWND __stdcall SUISkinGetAncestor(HWND Handle, unsigned gaFlags);
extern PACKAGE bool __fastcall IsWin95(void);
extern PACKAGE bool __fastcall IsWinXP(void);
extern PACKAGE bool __fastcall IsWinVista(void);
extern PACKAGE bool __fastcall HasProperty(Classes::TComponent* AComponent, System::UnicodeString ApropertyName);
extern PACKAGE System::UnicodeString __fastcall RemoveHotKey(const System::UnicodeString Source);
extern PACKAGE System::WideString __fastcall GetWindowString(unsigned hwnd);
extern PACKAGE Types::TRect __fastcall GetWorkAreaRect(unsigned hwnd);
extern PACKAGE void __fastcall PlaceControl(const Controls::TControl* Control, const Types::TPoint &Position)/* overload */;
extern PACKAGE void __fastcall PlaceControl(const Controls::TControl* Control, const Types::TRect &Rect)/* overload */;
extern PACKAGE bool __fastcall InRect(int X, int Y, const Types::TRect &Rect)/* overload */;
extern PACKAGE bool __fastcall InRect(const Types::TPoint &Point, const Types::TRect &Rect)/* overload */;
extern PACKAGE bool __fastcall InRect2(int X, int Y, const Types::TRect &Rect);
extern PACKAGE Forms::TCustomForm* __fastcall GetFormFromHandle(unsigned Handle);
extern PACKAGE bool __fastcall FormHasFocus(Forms::TCustomForm* Form);
extern PACKAGE void __fastcall GetCaptionFont(const Graphics::TFont* Font);
extern PACKAGE void __fastcall GetMenuFont(const Graphics::TFont* Font);
extern PACKAGE void __fastcall DrawControlBorder(Controls::TWinControl* WinControl, Graphics::TColor BorderColor, Graphics::TColor Color, bool DrawColor = true)/* overload */;
extern PACKAGE void __fastcall DrawControlBorder(unsigned hWnd, Graphics::TColor BorderColor, Graphics::TColor Color, bool DrawColor = true)/* overload */;
extern PACKAGE void __fastcall DrawArrowDown(const Graphics::TCanvas* ACanvas, int X, int Y, bool Enabled);
extern PACKAGE void __fastcall DrawArrowUp(const Graphics::TCanvas* ACanvas, int X, int Y, bool Enabled);
extern PACKAGE void __fastcall DrawArrowLeft(const Graphics::TCanvas* ACanvas, int X, int Y, bool Enabled);
extern PACKAGE void __fastcall DrawArrowRight(const Graphics::TCanvas* ACanvas, int X, int Y, bool Enabled);
extern PACKAGE void __fastcall ResizeImage(Graphics::TBitmap* SrcBmp, Graphics::TCanvas* tgtCanvas, const Types::TRect &tgtRect);
extern PACKAGE void __fastcall SpitDraw(Graphics::TBitmap* Source, Graphics::TCanvas* ACanvas, const Types::TRect &ARect, bool ATransparent, Graphics::TColor ATransparentColor);
extern PACKAGE void __fastcall ScanColor(const Graphics::TBitmap* Bmp, Graphics::TColor SrcColor, Graphics::TColor TgtColor);
extern PACKAGE void __fastcall DrawHorizontalGradient(const Graphics::TCanvas* ACanvas, const Types::TRect &ARect, const Graphics::TColor BeginColor, const Graphics::TColor EndColor);
extern PACKAGE void __fastcall DrawVerticalGradient(const Graphics::TCanvas* ACanvas, const Types::TRect &ARect, const Graphics::TColor BeginColor, const Graphics::TColor EndColor);
extern PACKAGE Graphics::TColor __fastcall GetInverseColor(const Graphics::TColor AColor);
extern PACKAGE void __fastcall Menu_SetItemEvent(Menus::TMenuItem* MenuItem, Menus::TMenuDrawItemEvent DrawItemEvent, Menus::TMenuMeasureItemEvent MeasureItemEvent);
extern PACKAGE Imglist::TCustomImageList* __fastcall Menu_GetImageList(Menus::TMenuItem* MenuItem);
extern PACKAGE void __fastcall Menu_DrawBorder(Graphics::TCanvas* ACanvas, const Types::TRect &ARect, Graphics::TColor Color);
extern PACKAGE void __fastcall Menu_DrawBackGround(Graphics::TCanvas* ACanvas, const Types::TRect &ARect, Graphics::TColor Color);
extern PACKAGE void __fastcall Menu_DrawLineItem(Graphics::TCanvas* ACanvas, const Types::TRect &ARect, Graphics::TColor LineColor, int BarWidth, bool BidiL2R);
extern PACKAGE System::UnicodeString __fastcall FormatStringWithWidth(Graphics::TCanvas* Canvas, const System::UnicodeString szPath, int nWidth);
extern PACKAGE System::WideString __fastcall FormatStringWithWidthW(Graphics::TCanvas* Canvas, const System::WideString szPath, int nWidth);
extern PACKAGE void __fastcall PaintRadioButtonLikeControl(bool Checked, bool Enabled, Graphics::TColor Color, Classes::TAlignment Alignment, TsuiSkinVAlignType VAlignment, int Width, int ClientHeight, System::TObject* Engine, System::TObject* SkinCtrl, bool CheckBox, int LeftOffset = 0x0);
extern PACKAGE void __fastcall PaintComboButtonLikeControl(const Controls::TControl* Control, const System::TObject* Engine, Graphics::TColor BtnFace);
extern PACKAGE void __fastcall PaintComboBoxLikeControl(const Controls::TControl* Control, const System::TObject* Engine, Graphics::TColor BtnFace);
extern PACKAGE void __fastcall CalcBitBtnLayout(Buttons::TButtonLayout Layout, int NumGlyphs, int Spacing, int Margin, System::UnicodeString Caption, const Graphics::TBitmap* Glyph, const Graphics::TBitmap* Buf, const Graphics::TFont* Font, const Controls::TControl* Control, /* out */ Types::TRect &TextRect, /* out */ Types::TPoint &GlyphPos);
extern PACKAGE void __fastcall PaintBitBtnLikeControl(bool Enabled, bool MouseDown, int NumGlyphs, const Types::TPoint &P, const Graphics::TBitmap* Glyph, const Graphics::TBitmap* Buf);
extern PACKAGE void __fastcall PaintButtonLikeControl(bool MouseDown, bool MouseIn, bool BitBtn, const Controls::TControl* Control, const Graphics::TFont* Font, const System::TObject* Engine, const System::TObject* SkinCtrl, TsuiSkinBitBtnPainter BitBtnPainter);
extern PACKAGE void __fastcall SpitDrawHorizontal(Graphics::TBitmap* Source, Graphics::TCanvas* ACanvas, const Types::TRect &ARect, bool ATransparent, Graphics::TColor ATransColor)/* overload */;
extern PACKAGE void __fastcall SpitDrawVertical(Graphics::TBitmap* Source, Graphics::TCanvas* ACanvas, const Types::TRect &ARect, int BorderWidth = 0x0);
extern PACKAGE void __fastcall SpitDrawHorizontal(Graphics::TBitmap* Source, Graphics::TCanvas* ACanvas, const Types::TRect &ARect, int BorderWidth)/* overload */;
extern PACKAGE void __fastcall SpitBitmap(Graphics::TBitmap* Source, Graphics::TBitmap* Dest, int Count, int Index);
extern PACKAGE void __fastcall RoundPicture(Graphics::TBitmap* SrcBuf);
extern PACKAGE void __fastcall RoundPicture2(Graphics::TBitmap* SrcBuf);
extern PACKAGE void __fastcall RoundPicture3(Graphics::TBitmap* SrcBuf);

}	/* namespace Suiskinutils */
using namespace Suiskinutils;
#pragma pack(pop)
#pragma option pop

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// SuiskinutilsHPP
