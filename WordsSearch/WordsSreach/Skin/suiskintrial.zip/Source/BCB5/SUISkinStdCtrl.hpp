// Borland C++ Builder
// Copyright (c) 1995, 1999 by Borland International
// All rights reserved

// (DO NOT EDIT: machine generated header) 'SUISkinStdCtrl.pas' rev: 5.00

#ifndef SUISkinStdCtrlHPP
#define SUISkinStdCtrlHPP

#pragma delphiheader begin
#pragma option push -w-
#pragma option push -Vx
#include <Dialogs.hpp>	// Pascal unit
#include <TypInfo.hpp>	// Pascal unit
#include <ImgList.hpp>	// Pascal unit
#include <Forms.hpp>	// Pascal unit
#include <SysUtils.hpp>	// Pascal unit
#include <ComCtrls.hpp>	// Pascal unit
#include <Grids.hpp>	// Pascal unit
#include <Commctrl.hpp>	// Pascal unit
#include <Buttons.hpp>	// Pascal unit
#include <ExtCtrls.hpp>	// Pascal unit
#include <SUISkinEngine.hpp>	// Pascal unit
#include <Math.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <Graphics.hpp>	// Pascal unit
#include <StdCtrls.hpp>	// Pascal unit
#include <Controls.hpp>	// Pascal unit
#include <Messages.hpp>	// Pascal unit
#include <Windows.hpp>	// Pascal unit
#include <SysInit.hpp>	// Pascal unit
#include <System.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Suiskinstdctrl
{
//-- type declarations -------------------------------------------------------
class DELPHICLASS TsuiSkinButton;
class PASCALIMPLEMENTATION TsuiSkinButton : public Suiskinengine::TsuiSkinControlVCL 
{
	typedef Suiskinengine::TsuiSkinControlVCL inherited;
	
private:
	bool m_Downed;
	bool m_KeyDowned;
	void __fastcall CalcBtnLayout(const Graphics::TBitmap* Buf, /* out */ Windows::TPoint &GlyphPos, /* out */ 
		Windows::TRect &TextRect);
	void __fastcall PaintBitBtn(const Graphics::TBitmap* Buf, /* out */ Windows::TRect &TextRect);
	void __fastcall CalcExBtnLayout(const Graphics::TBitmap* Buf, const Graphics::TBitmap* Glyph, int NumGlyphs
		, /* out */ Windows::TPoint &GlyphPos, /* out */ Windows::TRect &TextRect);
	void __fastcall PaintExBtn(const Graphics::TBitmap* Buf, /* out */ Windows::TRect &TextRect);
	void __fastcall CalcEx2BtnLayout(const Graphics::TBitmap* Buf, const Imglist::TCustomImageList* ImgList
		, /* out */ Windows::TPoint &GlyphPos, /* out */ Windows::TRect &TextRect);
	void __fastcall PaintEx2Btn(const Graphics::TBitmap* Buf, /* out */ Windows::TRect &TextRect);
	
protected:
	virtual bool __fastcall BeforeDefProc(Messages::TMessage &Message);
	virtual void __fastcall AfterDefProc(Messages::TMessage &Message);
	virtual void __fastcall PaintControl(void);
	virtual void __fastcall MouseUp(void);
	virtual void __fastcall MouseDown(void);
	virtual void __fastcall KeyUp(int VKey);
	virtual void __fastcall KeyDown(int VKey);
	virtual void __fastcall DoInit(void);
public:
	#pragma option push -w-inl
	/* TsuiSkinControlVCL.Create */ inline __fastcall TsuiSkinButton(Controls::TControl* WinCtrl, Suiskinengine::TsuiSkinWindow* 
		SkinWnd) : Suiskinengine::TsuiSkinControlVCL(WinCtrl, SkinWnd) { }
	#pragma option pop
	#pragma option push -w-inl
	/* TsuiSkinControlVCL.Destroy */ inline __fastcall virtual ~TsuiSkinButton(void) { }
	#pragma option pop
	
};


class DELPHICLASS TsuiSkinCheckBox;
class PASCALIMPLEMENTATION TsuiSkinCheckBox : public Suiskinengine::TsuiSkinControlVCL 
{
	typedef Suiskinengine::TsuiSkinControlVCL inherited;
	
private:
	Graphics::TColor m_OldFontColor;
	
protected:
	virtual void __fastcall PaintControl(void);
	virtual void __fastcall AfterDefProc(Messages::TMessage &Message);
	virtual void __fastcall ActiveChanged(void);
	virtual void __fastcall DoInit(void);
	virtual bool __fastcall BeforeDefProc(Messages::TMessage &Message);
public:
	#pragma option push -w-inl
	/* TsuiSkinControlVCL.Create */ inline __fastcall TsuiSkinCheckBox(Controls::TControl* WinCtrl, Suiskinengine::TsuiSkinWindow* 
		SkinWnd) : Suiskinengine::TsuiSkinControlVCL(WinCtrl, SkinWnd) { }
	#pragma option pop
	#pragma option push -w-inl
	/* TsuiSkinControlVCL.Destroy */ inline __fastcall virtual ~TsuiSkinCheckBox(void) { }
	#pragma option pop
	
};


class DELPHICLASS TsuiSkinRadioButton;
class PASCALIMPLEMENTATION TsuiSkinRadioButton : public Suiskinengine::TsuiSkinControlVCL 
{
	typedef Suiskinengine::TsuiSkinControlVCL inherited;
	
private:
	Graphics::TColor m_OldFontColor;
	
protected:
	virtual bool __fastcall BeforeDefProc(Messages::TMessage &Message);
	virtual void __fastcall PaintControl(void);
	virtual void __fastcall ActiveChanged(void);
	virtual void __fastcall DoInit(void);
	virtual void __fastcall AfterDefProc(Messages::TMessage &Message);
public:
	#pragma option push -w-inl
	/* TsuiSkinControlVCL.Create */ inline __fastcall TsuiSkinRadioButton(Controls::TControl* WinCtrl, 
		Suiskinengine::TsuiSkinWindow* SkinWnd) : Suiskinengine::TsuiSkinControlVCL(WinCtrl, SkinWnd) { }
	#pragma option pop
	#pragma option push -w-inl
	/* TsuiSkinControlVCL.Destroy */ inline __fastcall virtual ~TsuiSkinRadioButton(void) { }
	#pragma option pop
	
};


class DELPHICLASS TsuiSkinComboBox;
class PASCALIMPLEMENTATION TsuiSkinComboBox : public Suiskinengine::TsuiSkinControlVCL 
{
	typedef Suiskinengine::TsuiSkinControlVCL inherited;
	
protected:
	virtual void __fastcall PaintControl(void);
public:
	#pragma option push -w-inl
	/* TsuiSkinControlVCL.Create */ inline __fastcall TsuiSkinComboBox(Controls::TControl* WinCtrl, Suiskinengine::TsuiSkinWindow* 
		SkinWnd) : Suiskinengine::TsuiSkinControlVCL(WinCtrl, SkinWnd) { }
	#pragma option pop
	#pragma option push -w-inl
	/* TsuiSkinControlVCL.Destroy */ inline __fastcall virtual ~TsuiSkinComboBox(void) { }
	#pragma option pop
	
};


class DELPHICLASS TsuiSkinComboBoxEx;
class PASCALIMPLEMENTATION TsuiSkinComboBoxEx : public Suiskinengine::TsuiSkinControlVCL 
{
	typedef Suiskinengine::TsuiSkinControlVCL inherited;
	
protected:
	virtual void __fastcall PaintControl(void);
	virtual void __fastcall AfterDefProc(Messages::TMessage &Message);
public:
	#pragma option push -w-inl
	/* TsuiSkinControlVCL.Create */ inline __fastcall TsuiSkinComboBoxEx(Controls::TControl* WinCtrl, Suiskinengine::TsuiSkinWindow* 
		SkinWnd) : Suiskinengine::TsuiSkinControlVCL(WinCtrl, SkinWnd) { }
	#pragma option pop
	#pragma option push -w-inl
	/* TsuiSkinControlVCL.Destroy */ inline __fastcall virtual ~TsuiSkinComboBoxEx(void) { }
	#pragma option pop
	
};


class DELPHICLASS TsuiSkinInternalScrollBar2;
class PASCALIMPLEMENTATION TsuiSkinInternalScrollBar2 : public Extctrls::TCustomPanel 
{
	typedef Extctrls::TCustomPanel inherited;
	
private:
	Stdctrls::TScrollBar* m_Control;
	Graphics::TBitmap* m_Buf;
	HIDESBASE MESSAGE void __fastcall WMLBUTTONDOWN(Messages::TMessage &Msg);
	HIDESBASE MESSAGE void __fastcall WMLBUTTONUP(Messages::TMessage &Msg);
	HIDESBASE MESSAGE void __fastcall WMMOUSEMOVE(Messages::TMessage &Msg);
	HIDESBASE MESSAGE void __fastcall WMERASEBKGND(Messages::TMessage &Msg);
	
protected:
	virtual void __fastcall Paint(void);
	
public:
	__fastcall virtual TsuiSkinInternalScrollBar2(Classes::TComponent* AOwner);
	__fastcall virtual ~TsuiSkinInternalScrollBar2(void);
public:
	#pragma option push -w-inl
	/* TWinControl.CreateParented */ inline __fastcall TsuiSkinInternalScrollBar2(HWND ParentWindow) : 
		Extctrls::TCustomPanel(ParentWindow) { }
	#pragma option pop
	
};


class DELPHICLASS TsuiSkinScrollBar;
class PASCALIMPLEMENTATION TsuiSkinScrollBar : public Suiskinengine::TsuiSkinControlVCL 
{
	typedef Suiskinengine::TsuiSkinControlVCL inherited;
	
private:
	TsuiSkinInternalScrollBar2* m_Scroll;
	
protected:
	virtual void __fastcall DoInit(void);
	virtual void __fastcall DoUninit(void);
	virtual void __fastcall ActiveChanged(void);
	virtual void __fastcall AfterDefProc(Messages::TMessage &Message);
	virtual void __fastcall PaintControl(void);
public:
	#pragma option push -w-inl
	/* TsuiSkinControlVCL.Create */ inline __fastcall TsuiSkinScrollBar(Controls::TControl* WinCtrl, Suiskinengine::TsuiSkinWindow* 
		SkinWnd) : Suiskinengine::TsuiSkinControlVCL(WinCtrl, SkinWnd) { }
	#pragma option pop
	#pragma option push -w-inl
	/* TsuiSkinControlVCL.Destroy */ inline __fastcall virtual ~TsuiSkinScrollBar(void) { }
	#pragma option pop
	
};


class DELPHICLASS TsuiSkinGroupBox;
class PASCALIMPLEMENTATION TsuiSkinGroupBox : public Suiskinengine::TsuiSkinControlVCL 
{
	typedef Suiskinengine::TsuiSkinControlVCL inherited;
	
protected:
	virtual void __fastcall PaintControl(void);
	
public:
	virtual bool __fastcall ParentColor(void);
public:
	#pragma option push -w-inl
	/* TsuiSkinControlVCL.Create */ inline __fastcall TsuiSkinGroupBox(Controls::TControl* WinCtrl, Suiskinengine::TsuiSkinWindow* 
		SkinWnd) : Suiskinengine::TsuiSkinControlVCL(WinCtrl, SkinWnd) { }
	#pragma option pop
	#pragma option push -w-inl
	/* TsuiSkinControlVCL.Destroy */ inline __fastcall virtual ~TsuiSkinGroupBox(void) { }
	#pragma option pop
	
};


class DELPHICLASS TsuiSkinPanel;
class PASCALIMPLEMENTATION TsuiSkinPanel : public Suiskinengine::TsuiSkinControlVCL 
{
	typedef Suiskinengine::TsuiSkinControlVCL inherited;
	
public:
	virtual bool __fastcall ParentColor(void);
public:
	#pragma option push -w-inl
	/* TsuiSkinControlVCL.Create */ inline __fastcall TsuiSkinPanel(Controls::TControl* WinCtrl, Suiskinengine::TsuiSkinWindow* 
		SkinWnd) : Suiskinengine::TsuiSkinControlVCL(WinCtrl, SkinWnd) { }
	#pragma option pop
	#pragma option push -w-inl
	/* TsuiSkinControlVCL.Destroy */ inline __fastcall virtual ~TsuiSkinPanel(void) { }
	#pragma option pop
	
};


class DELPHICLASS TsuiSkinSpeedButton;
class PASCALIMPLEMENTATION TsuiSkinSpeedButton : public Suiskinengine::TsuiSkinControlVCL 
{
	typedef Suiskinengine::TsuiSkinControlVCL inherited;
	
private:
	void __fastcall CalcBtnLayout(const Graphics::TCanvas* Buf, /* out */ Windows::TPoint &GlyphPos, /* out */ 
		Windows::TRect &TextRect);
	void __fastcall PaintGlyph(const Graphics::TCanvas* Canvas, const Windows::TPoint &Pos);
	void __fastcall PaintText(const Graphics::TCanvas* Canvas, const Windows::TRect &Rect);
	void __fastcall PaintHot(const Graphics::TCanvas* Canvas);
	void __fastcall PaintDown(const Graphics::TCanvas* Canvas);
	void __fastcall PaintNormal(const Graphics::TCanvas* Canvas);
	
protected:
	virtual bool __fastcall BeforeDefProc(Messages::TMessage &Message);
	virtual void __fastcall PaintControl(void);
public:
	#pragma option push -w-inl
	/* TsuiSkinControlVCL.Create */ inline __fastcall TsuiSkinSpeedButton(Controls::TControl* WinCtrl, 
		Suiskinengine::TsuiSkinWindow* SkinWnd) : Suiskinengine::TsuiSkinControlVCL(WinCtrl, SkinWnd) { }
	#pragma option pop
	#pragma option push -w-inl
	/* TsuiSkinControlVCL.Destroy */ inline __fastcall virtual ~TsuiSkinSpeedButton(void) { }
	#pragma option pop
	
};


class DELPHICLASS TsuiSkinGrid;
class PASCALIMPLEMENTATION TsuiSkinGrid : public Suiskinengine::TsuiSkinScrollWinControl 
{
	typedef Suiskinengine::TsuiSkinScrollWinControl inherited;
	
private:
	Graphics::TColor m_OldFixedColor;
	
protected:
	virtual void __fastcall DoInit(void);
	virtual void __fastcall ActiveChanged(void);
public:
	#pragma option push -w-inl
	/* TsuiSkinControlVCL.Create */ inline __fastcall TsuiSkinGrid(Controls::TControl* WinCtrl, Suiskinengine::TsuiSkinWindow* 
		SkinWnd) : Suiskinengine::TsuiSkinScrollWinControl(WinCtrl, SkinWnd) { }
	#pragma option pop
	#pragma option push -w-inl
	/* TsuiSkinControlVCL.Destroy */ inline __fastcall virtual ~TsuiSkinGrid(void) { }
	#pragma option pop
	
};


class DELPHICLASS TsuiSkinTabControl;
class PASCALIMPLEMENTATION TsuiSkinTabControl : public Suiskinengine::TsuiSkinControlVCL 
{
	typedef Suiskinengine::TsuiSkinControlVCL inherited;
	
private:
	void __fastcall PaintPage(const Graphics::TBitmap* Buf, int PageIndex, const Windows::TRect &R, bool 
		Active);
	
protected:
	virtual bool __fastcall BeforeDefProc(Messages::TMessage &Message);
	virtual void __fastcall PaintControl(void);
	virtual WideString __fastcall GetTextForTNT(int Id);
public:
	#pragma option push -w-inl
	/* TsuiSkinControlVCL.Create */ inline __fastcall TsuiSkinTabControl(Controls::TControl* WinCtrl, Suiskinengine::TsuiSkinWindow* 
		SkinWnd) : Suiskinengine::TsuiSkinControlVCL(WinCtrl, SkinWnd) { }
	#pragma option pop
	#pragma option push -w-inl
	/* TsuiSkinControlVCL.Destroy */ inline __fastcall virtual ~TsuiSkinTabControl(void) { }
	#pragma option pop
	
};


class DELPHICLASS TsuiSkinTrackBar;
class PASCALIMPLEMENTATION TsuiSkinTrackBar : public Suiskinengine::TsuiSkinControlVCL 
{
	typedef Suiskinengine::TsuiSkinControlVCL inherited;
	
private:
	Graphics::TBitmap* m_BarImg;
	
protected:
	virtual void __fastcall ActiveChanged(void);
	virtual bool __fastcall BeforeDefProc(Messages::TMessage &Message);
	virtual void __fastcall PaintControl(void);
	virtual void __fastcall DoUninit(void);
public:
	#pragma option push -w-inl
	/* TsuiSkinControlVCL.Create */ inline __fastcall TsuiSkinTrackBar(Controls::TControl* WinCtrl, Suiskinengine::TsuiSkinWindow* 
		SkinWnd) : Suiskinengine::TsuiSkinControlVCL(WinCtrl, SkinWnd) { }
	#pragma option pop
	#pragma option push -w-inl
	/* TsuiSkinControlVCL.Destroy */ inline __fastcall virtual ~TsuiSkinTrackBar(void) { }
	#pragma option pop
	
};


class DELPHICLASS TsuiSkinProgressBar;
class PASCALIMPLEMENTATION TsuiSkinProgressBar : public Suiskinengine::TsuiSkinControlVCL 
{
	typedef Suiskinengine::TsuiSkinControlVCL inherited;
	
protected:
	virtual bool __fastcall BeforeDefProc(Messages::TMessage &Message);
	virtual void __fastcall AfterDefProc(Messages::TMessage &Message);
	virtual void __fastcall PaintControl(void);
public:
	#pragma option push -w-inl
	/* TsuiSkinControlVCL.Create */ inline __fastcall TsuiSkinProgressBar(Controls::TControl* WinCtrl, 
		Suiskinengine::TsuiSkinWindow* SkinWnd) : Suiskinengine::TsuiSkinControlVCL(WinCtrl, SkinWnd) { }
	#pragma option pop
	#pragma option push -w-inl
	/* TsuiSkinControlVCL.Destroy */ inline __fastcall virtual ~TsuiSkinProgressBar(void) { }
	#pragma option pop
	
};


class DELPHICLASS TsuiSkinUpDown;
class PASCALIMPLEMENTATION TsuiSkinUpDown : public Suiskinengine::TsuiSkinControlVCL 
{
	typedef Suiskinengine::TsuiSkinControlVCL inherited;
	
private:
	int m_R;
	
protected:
	virtual bool __fastcall BeforeDefProc(Messages::TMessage &Message);
	virtual void __fastcall PaintControl(void);
public:
	#pragma option push -w-inl
	/* TsuiSkinControlVCL.Create */ inline __fastcall TsuiSkinUpDown(Controls::TControl* WinCtrl, Suiskinengine::TsuiSkinWindow* 
		SkinWnd) : Suiskinengine::TsuiSkinControlVCL(WinCtrl, SkinWnd) { }
	#pragma option pop
	#pragma option push -w-inl
	/* TsuiSkinControlVCL.Destroy */ inline __fastcall virtual ~TsuiSkinUpDown(void) { }
	#pragma option pop
	
};


class DELPHICLASS TsuiSkinStatusBar;
class PASCALIMPLEMENTATION TsuiSkinStatusBar : public Suiskinengine::TsuiSkinControlVCL 
{
	typedef Suiskinengine::TsuiSkinControlVCL inherited;
	
protected:
	virtual void __fastcall PaintControl(void);
	
public:
	virtual bool __fastcall ParentColor(void);
public:
	#pragma option push -w-inl
	/* TsuiSkinControlVCL.Create */ inline __fastcall TsuiSkinStatusBar(Controls::TControl* WinCtrl, Suiskinengine::TsuiSkinWindow* 
		SkinWnd) : Suiskinengine::TsuiSkinControlVCL(WinCtrl, SkinWnd) { }
	#pragma option pop
	#pragma option push -w-inl
	/* TsuiSkinControlVCL.Destroy */ inline __fastcall virtual ~TsuiSkinStatusBar(void) { }
	#pragma option pop
	
};


class DELPHICLASS TsuiSkinToolBar;
class PASCALIMPLEMENTATION TsuiSkinToolBar : public Suiskinengine::TsuiSkinControlVCL 
{
	typedef Suiskinengine::TsuiSkinControlVCL inherited;
	
private:
	bool m_OldFlat;
	Graphics::TColor m_OldColor;
	void __fastcall DrawButton(Comctrls::TToolBar* Sender, Comctrls::TToolButton* Button, Comctrls::TCustomDrawState 
		State, bool &DefaultDraw);
	void __fastcall DrawBar(Comctrls::TToolBar* Sender, const Windows::TRect &ARect, bool &DefaultDraw)
		;
	void __fastcall DrawDownButton(Graphics::TCanvas* ACanvas, const Windows::TRect &ARect, Imglist::TCustomImageList* 
		ImgLst, int ImageIndex, AnsiString CaptionStr, bool DropDown);
	void __fastcall DrawHotButton(Graphics::TCanvas* ACanvas, const Windows::TRect &ARect, Imglist::TCustomImageList* 
		ImgLst, int ImageIndex, AnsiString CaptionStr, bool DropDown);
	
protected:
	virtual void __fastcall DoInit(void);
	virtual void __fastcall DoUninit(void);
	virtual void __fastcall ActiveChanged(void);
	
public:
	virtual bool __fastcall ParentColor(void);
public:
	#pragma option push -w-inl
	/* TsuiSkinControlVCL.Create */ inline __fastcall TsuiSkinToolBar(Controls::TControl* WinCtrl, Suiskinengine::TsuiSkinWindow* 
		SkinWnd) : Suiskinengine::TsuiSkinControlVCL(WinCtrl, SkinWnd) { }
	#pragma option pop
	#pragma option push -w-inl
	/* TsuiSkinControlVCL.Destroy */ inline __fastcall virtual ~TsuiSkinToolBar(void) { }
	#pragma option pop
	
};


class DELPHICLASS TsuiSkinFrame;
class PASCALIMPLEMENTATION TsuiSkinFrame : public Suiskinengine::TsuiSkinControlVCL 
{
	typedef Suiskinengine::TsuiSkinControlVCL inherited;
	
public:
	#pragma option push -w-inl
	/* TsuiSkinControlVCL.Create */ inline __fastcall TsuiSkinFrame(Controls::TControl* WinCtrl, Suiskinengine::TsuiSkinWindow* 
		SkinWnd) : Suiskinengine::TsuiSkinControlVCL(WinCtrl, SkinWnd) { }
	#pragma option pop
	#pragma option push -w-inl
	/* TsuiSkinControlVCL.Destroy */ inline __fastcall virtual ~TsuiSkinFrame(void) { }
	#pragma option pop
	
};


class DELPHICLASS TsuiSkinInternalUpDown;
class DELPHICLASS TsuiSkinDateTimePicker;
class PASCALIMPLEMENTATION TsuiSkinDateTimePicker : public Suiskinengine::TsuiSkinExtComboboxLikeControl 
	
{
	typedef Suiskinengine::TsuiSkinExtComboboxLikeControl inherited;
	
private:
	TsuiSkinInternalUpDown* m_Spin;
	bool __fastcall BtnVisible(void);
	
protected:
	virtual void __fastcall DoInit(void);
	virtual void __fastcall DoUninit(void);
	virtual void __fastcall ActiveChanged(void);
public:
	#pragma option push -w-inl
	/* TsuiSkinControlVCL.Create */ inline __fastcall TsuiSkinDateTimePicker(Controls::TControl* WinCtrl
		, Suiskinengine::TsuiSkinWindow* SkinWnd) : Suiskinengine::TsuiSkinExtComboboxLikeControl(WinCtrl, 
		SkinWnd) { }
	#pragma option pop
	#pragma option push -w-inl
	/* TsuiSkinControlVCL.Destroy */ inline __fastcall virtual ~TsuiSkinDateTimePicker(void) { }
	#pragma option pop
	
};


class PASCALIMPLEMENTATION TsuiSkinInternalUpDown : public Comctrls::TUpDown 
{
	typedef Comctrls::TUpDown inherited;
	
private:
	Controls::TWinControl* m_Ctrl;
	TsuiSkinDateTimePicker* m_SkinCtrl;
	HIDESBASE MESSAGE void __fastcall WMLBUTTONDOWN(Messages::TMessage &Msg);
	HIDESBASE MESSAGE void __fastcall WMLBUTTONUP(Messages::TMessage &Msg);
	HIDESBASE MESSAGE void __fastcall WMLBUTTONDBLCLK(Messages::TMessage &Msg);
	MESSAGE void __fastcall WMNCNITTEST(Messages::TMessage &Msg);
	HIDESBASE MESSAGE void __fastcall WMERASEBKGND(Messages::TMessage &Msg);
	
public:
	__fastcall virtual TsuiSkinInternalUpDown(Classes::TComponent* AOwner);
	__fastcall virtual ~TsuiSkinInternalUpDown(void);
public:
	#pragma option push -w-inl
	/* TWinControl.CreateParented */ inline __fastcall TsuiSkinInternalUpDown(HWND ParentWindow) : Comctrls::TUpDown(
		ParentWindow) { }
	#pragma option pop
	
};


class DELPHICLASS TsuiSkinListView;
class PASCALIMPLEMENTATION TsuiSkinListView : public Suiskinengine::TsuiSkinScrollWinControl 
{
	typedef Suiskinengine::TsuiSkinScrollWinControl inherited;
	
private:
	unsigned m_Header;
	void *m_OldProc;
	unsigned m_Handle;
	void __fastcall HeaderWndProc(Messages::TMessage &Message);
	void __fastcall PaintHeader(void);
	
protected:
	virtual void __fastcall DoInit(void);
	virtual void __fastcall DoUninit(void);
public:
	#pragma option push -w-inl
	/* TsuiSkinControlVCL.Create */ inline __fastcall TsuiSkinListView(Controls::TControl* WinCtrl, Suiskinengine::TsuiSkinWindow* 
		SkinWnd) : Suiskinengine::TsuiSkinScrollWinControl(WinCtrl, SkinWnd) { }
	#pragma option pop
	#pragma option push -w-inl
	/* TsuiSkinControlVCL.Destroy */ inline __fastcall virtual ~TsuiSkinListView(void) { }
	#pragma option pop
	
};


class DELPHICLASS TsuiSkinLabel;
class PASCALIMPLEMENTATION TsuiSkinLabel : public Suiskinengine::TsuiSkinControlVCL 
{
	typedef Suiskinengine::TsuiSkinControlVCL inherited;
	
private:
	Graphics::TColor m_OldFontColor;
	
protected:
	virtual void __fastcall DoInit(void);
	virtual void __fastcall ActiveChanged(void);
	
public:
	virtual bool __fastcall ParentColor(void);
public:
	#pragma option push -w-inl
	/* TsuiSkinControlVCL.Create */ inline __fastcall TsuiSkinLabel(Controls::TControl* WinCtrl, Suiskinengine::TsuiSkinWindow* 
		SkinWnd) : Suiskinengine::TsuiSkinControlVCL(WinCtrl, SkinWnd) { }
	#pragma option pop
	#pragma option push -w-inl
	/* TsuiSkinControlVCL.Destroy */ inline __fastcall virtual ~TsuiSkinLabel(void) { }
	#pragma option pop
	
};


//-- var, const, procedure ---------------------------------------------------
extern PACKAGE Suiskinengine::TsuiSkinCtrlVCLDef SUISKIN_STDCTRLS_DEF[26];
static const int SUISKIN_3RD_SPEEDBUTTON_TAG = 0xf423f;

}	/* namespace Suiskinstdctrl */
#if !defined(NO_IMPLICIT_NAMESPACE_USE)
using namespace Suiskinstdctrl;
#endif
#pragma option pop	// -w-
#pragma option pop	// -Vx

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// SUISkinStdCtrl
