// Borland C++ Builder
// Copyright (c) 1995, 2002 by Borland Software Corporation
// All rights reserved

// (DO NOT EDIT: machine generated header) 'Skin2SkinReader.pas' rev: 6.00

#ifndef Skin2SkinReaderHPP
#define Skin2SkinReaderHPP

#pragma delphiheader begin
#pragma option push -w-
#pragma option push -Vx
#include <Graphics.hpp>	// Pascal unit
#include <SysUtils.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <Windows.hpp>	// Pascal unit
#include <SysInit.hpp>	// Pascal unit
#include <System.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Skin2skinreader
{
//-- type declarations -------------------------------------------------------
class DELPHICLASS Tsk2SkinFileReader;
class PASCALIMPLEMENTATION Tsk2SkinFileReader : public System::TObject 
{
	typedef System::TObject inherited;
	
private:
	Classes::TStrings* m_BitmapList;
	Classes::TStrings* m_IntegerList;
	Classes::TStrings* m_BooleanList;
	Classes::TStrings* m_StrList;
	void __fastcall Load(AnsiString FileName, AnsiString Password);
	
public:
	__fastcall Tsk2SkinFileReader(AnsiString FileName, AnsiString Password);
	__fastcall virtual ~Tsk2SkinFileReader(void);
	Graphics::TBitmap* __fastcall GetBitmap(AnsiString Key);
	int __fastcall GetInteger(AnsiString Key);
	bool __fastcall GetBool(AnsiString Key);
	AnsiString __fastcall GetStr(AnsiString Key);
	void __fastcall SetInteger(AnsiString Key, int Value);
	void __fastcall SetBool(AnsiString Key, bool Value);
	void __fastcall SetBitmap(AnsiString Key, const Graphics::TBitmap* Buf);
	void __fastcall ProcessTransparentColor(Graphics::TColor TransColor);
};


//-- var, const, procedure ---------------------------------------------------

}	/* namespace Skin2skinreader */
using namespace Skin2skinreader;
#pragma option pop	// -w-
#pragma option pop	// -Vx

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// Skin2SkinReader
