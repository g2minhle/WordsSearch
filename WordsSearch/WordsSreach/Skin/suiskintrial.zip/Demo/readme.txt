Since the location of the skin files are not same between ours and yours.
Before run the project, you should re-specify the SkinFile property and
the SkinFile of each item in AdditionalBuiltInSkins property. Or the form
will come with non-skinned.

Then skins will be built-into the EXE file(set BuiltIn property to true),
so you don't need worry about this for the end users who run your EXE file.